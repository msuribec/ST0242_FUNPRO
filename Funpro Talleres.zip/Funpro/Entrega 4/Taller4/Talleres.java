




import java.util.*;
//Solución taller 4
//María Sofía Uribe 
//Febrero 2017
public class Talleres {
    public static void main(String []args){
        //punto1A();
        //punto1B(2);
        //punto1C(3,2);
        //punto1D(5);
        //punto1E();
        //punto1F(3,5);
        //punto1G(5);
        //punto1H(1);
        //punto1I();
        //punto1J();
        //punto1K(5,2);
        //punto1L(6);
        //punto1M();
        //punto1N();
        //punto1O(4);
        //punto1P();
        //punto1Q(1,4);
        //punto1R();

    }

    public static void punto1A() {
        for (int i =30 ;i>= -30; i-- ){
            if (i %5 == 0){
                System.out.println(i);
            }
        }
    }

    public static void punto1B(int n) {
        int sum =0;
        for (int i =-n ;i<= n; i++ ){
            sum += 7 * (i*i*i) - 9;
        }
        System.out.println(sum);
    }

    public static void punto1C(int n , int m) {

        if (n>m && n>0 && m>0){
            int prod =1;
            for (int i =0 ;i<= m; i++ ){
                int sum = 0;
                for (int j =i ;j<= n; j++ ){
                    sum += 3* i + 4*j;
                }
                prod *= (sum + (2*i));
            }
            System.out.println("El resultado es: "+ prod);
        }else {
            System.out.println("Números no válidos" );
        }
    }

    // Método factorial ();
    public static double punto1D(double num) {
        double factorial =1;
        for (double i = num; i > 0 ; i--){

            factorial *= i ;
        }
        return factorial;
    }

    public static void punto1E() {
        for (int a =1 ;a <= 10; a++ ){
            for (int b =1 ;b <= 10; b++ ){
                System.out.println( a +" x "+ b + " = " + (a* b));
            }
        }
    }
    // Método potencia ();
    public static double punto1F(double base, double exponente ) {
        double resultado = 1 ;
        for (int i= 1 ; i<= exponente ; i++){
            resultado *= base;
        }

        return resultado;
    }

    public static void punto1G(int numero) {
        if (numero > 0){
            System.out.print("Los divisores de " + numero + " son: ");
            for (int i= 1 ; i<= numero; i++){
                if (numero % i == 0){
                    System.out.print(i + " ");
                }
            }
        }else {
            System.out.println("El numero debe ser positivo");
        }

    }

    public static void punto1H(int numH) {
        if (numH == 1){
            System.out.println("Por definición , uno no es primo ni compuesto");
        }else if (numH > 0){
            int cuenta = 0;
            for (int i= 1 ; i<= numH; i++){
                if (numH % i == 0){
                    cuenta++;
                }
            }
            if (cuenta > 2 ){
                System.out.println("compuesto");
            }else {
                System.out.println("primo");
            }
        }else {
            System.out.println("El numero debe ser positivo");
        }

    }

    public static void punto1I() {
            int num;
            do {
                System.out.println("Entra un número entero: ");
                Scanner in = new Scanner(System.in);
                num = in.nextInt();
                if (num >= 1 && num<= 5){
                    System.out.println(num + " es válido. Pasa");

                }
            } while(num < 1 || num > 5);
        }

    public static void punto1J() {
            double serie = 0;
            double termino;
            double n = 0;
            do{
                termino = (punto1F(-1, n) / punto1D(2 * n)) * punto1F((Math.PI/3 ), (2*n));
                serie += termino;
                n++;
            }while(Math.abs(termino) >= 0.0001);
            System.out.println(serie);
        }

    //  Este método recibe dos numeros enteros e imprime el máximo común divisor de estos números
    public static void punto1K(int m , int n) {
        if (m < n) {
            int moriginal = m;
            m = n;
            n = moriginal;
        }
        while (n!= 0){
            int r = m % n;
            m = n;
            n = r;
        }
        System.out.println(m);
    }

    public static void punto1L(int fibo) {
        if(fibo >= 3){
            System.out.println(0 + "\n" + "1");
            for (int i= 1 ;i<= fibo-2;i++){
                System.out.println(i);
            }

        }else {
            System.out.println("el número debe ser mayor o igual a 3");
        }
    }
    public static void punto1M() {

        System.out.print("Entre un número negativo (positivo para parar ) : ");
        Scanner console = new Scanner(System.in);
        int num = console.nextInt();
        int minimo = num, maximo = num;

        while (num < 0) {
            if (num < minimo) {
                minimo = num;
            } else if (num > maximo) {
                maximo = num;
            }
            System.out.print("Entre un número negativo (positivo para parar ) : ");
            num = console.nextInt();
        }

        System.out.println("Maximum was " + maximo);
        System.out.println("Minimum was " + minimo);

    }

    public static void punto1N() {

        System.out.print("Entre un número entre 2 y 12 : ");
        Scanner console = new Scanner(System.in);
        int a, b ,suma = console.nextInt();
        System.out.println(" Suma deseada es " + suma );
        if (suma < 2 || suma > 12) {
            System.out.println("suma no válida");
        }else {
           do{
               Random rand = new Random();
               a = rand.nextInt(6) + 1;
               b = rand.nextInt(6) + 1;
               System.out.println( a + " + "+ b + " = " + (a+b));
            } while ((a+b) != suma);
        }
    }


    public static void punto1O(int n) {
         int nOriginal = n;
        if (n <= 0){
            System.out.print("El número debe ser mayor de 0");
        }
        int cuenta =0;
        while (n>0){
            int puntos =0;
            for (int i = n - 1; i >= 1; i--) {
                System.out.print(".");
                puntos++;
            }
            System.out.print(n);
            puntos++;
            if (cuenta >= 1){
                for (int j = 1; j <= nOriginal - puntos; j++) {
                    System.out.print("*");
                }
            }
            n--;
            cuenta ++;
            System.out.print("\n");
        }

    }

    public static void punto1P() {
        System.out.println("12:00");
        for (int i = 11; i >= 0; i--) {
            for (int j = 59; j >= 0; j--) {
                if (j ==0 ){
                    System.out.println(i+":"+j+ "0");
                }else if (j <10){
                    System.out.println(i+":"+"0"+j);
                }else {
                    System.out.println(i+":"+j);
                }
            }
        }
    }

    public static void punto1Q(double radio, double revEje ) {

        for (double i = 0; i <= radio; i += 0.1 ){
            double distancia = 2* Math.PI * radio * revEje ;
            System.out.println("radio = "+ i + " - revoluciones = "+ revEje +"  - distancia = " + distancia);
        }

    }

    public static void punto1R() {

       int  cant1 = 0,totalfacturas = 0, cuentasgrandes= 0;

       for (int numfacturas = 1; numfacturas<= 5 ; numfacturas++ ){
           System.out.println("FACTURA No: " + numfacturas);
           System.out.println("Código del artículo ");
           Scanner console = new Scanner(System.in);
           int codArt = console.nextInt();
           System.out.println("litros vendidos del artículo: ");
           int cant = console.nextInt();
           System.out.println("precio por litro del artículo: ");
           int precio = console.nextInt();

           if (codArt == 1){
               cant1 += cant;
           }
           int totalestafactura =cant*precio;
           totalfacturas += totalestafactura;
           if (totalestafactura > 500000){
               cuentasgrandes++;
           }
       }
        System.out.println("FACTURA FINAL: ");
        System.out.println("total: "+ totalfacturas);
        System.out.println("cantidad vendida del artículo 1: "+ cant1);
        System.out.println("cuentas de más de 500 000: "+ cuentasgrandes);
    }

    public static void punto1S() {

        for (int a =0 ; a <= 9; a++ ) {
            for (int b =0 ; b <= 9; b++ ) {
                for (int c =0 ; c <= 9; c++ ) {
                    for (int d =0 ; d <= 9; d ++ ) {
                        for (int e =0 ; e <= 9; e++ ) {
                            String Secuencia = a + " - " + b  + " - " + c  + " - "+ d + " - " + e;
                            String Secuencia1 =Secuencia.replaceAll("1", "I");
                            String Secuencia2 = Secuencia1.replaceAll("3", "E");
                            System.out.println(Secuencia2);
                        }
                    }
                }
            }
        }
    }
    }
