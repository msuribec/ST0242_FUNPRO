/**
 * Soluciones al taller 2.
 *
 * @author María Sofía Uribe
 * @version Febrero 2017
 */
public class  taller2{
    // Método principal -> llama a cada método
    public static void main(String []args){
        ejercicio6 (11,3);
        ejercicio7 (1, 3);
        ejercicio8 (4.5f, 4.0f, 4.0f,2.8f);
        ejercicio9(100);
        ejercicio10(2000);
        ejercicio11(3,0.7);
        ejercicio12(456);
    }
    // El punto 6 toma dos números enteros a y b y realiza la división euclídea (truncada) a/b e imprime el cociente (un numero entero)
    public static int ejercicio6 (int a, int b) {

        int c = (a/b) , residuo =  a - (c*b);
        System.out.println("Punto 6 : El residuo de " + a + "/" + b + " es: "+ residuo);
        return residuo;
    }
    // El punto 7 toma dos números enteros a y b , y  evalua la expresión en el binomio al cubo  a3 + 3a2b + 3ab2 + b3
    public static int ejercicio7 (int a, int b) {

        int c= (a+b)*(a+b)*(a+b);
        System.out.println("Punto 7 : el binomio al cubo (a+b)^3 , cuando a es " + a + " y b es " + b + " = "+ c);
        return c;
    }
    // El punto 8 toma 4 notas (numeros de punto flotante) y computa la nota necesitada para completar el 100% de la materia con una nota de 4.0
    public static double ejercicio8 (float parcial1, float parcial2, float parcial3, float seguimiento){

        Double nota = (double) (parcial1 * 0.15f +parcial2 * 0.20f + parcial3 * 0.25f + seguimiento * 0.20f) ;
        double notaPractica = (4.0 - nota)/ 0.20;
        System.out.println("Punto 8 : necesitas "+ notaPractica + " para obtener 4.0 en la materia");
        return nota;
    }

/**El punto 9 toma un número entero de unidades y calcula cuántas cajas (cada una de 18 unidades) se pueden formar ,
    cuántos six packs (cado una de 6 unidades) se pueden formar  , y cuantas unidades se necesitan para formar una caja más y un six pack más*/

    public static int ejercicio9(int unidades){


        int cajas =unidades /18;
        int sixPacks = unidades/6;
        int faltaSP = 6 -(unidades % 6);
        int faltaC = 18 -(unidades % 18);
        System.out.println("Punto 9 : Se pueden crear " + sixPacks + " six packs . Para crear " + (sixPacks + 1) + 
        " six packs se necesitan " + faltaSP + " unidades más." + "\n o se pueden crear " + cajas + " cajas. Para crear " 
        + (cajas + 1) + " cajas se necesitan " +  faltaC + " unidades más");
        return unidades;
    }
    // El punto 10 toma un numero de horas entero y computa el número de semanas, días y horas equivalentes.
    public static int ejercicio10(int horas){

        int semanas = horas/168;
        int dias = (horas % 168)/24;
        horas = (horas % 168) % 24;
        System.out.println("punto 10 : " + semanas + " semanas, " + dias + " dias y " + horas + " horas.");
        return horas;
    }
    // El punto 11 calcula la altura que se puede alcanzar con una escalera de 3 metros que está apoyada sobre la pared
    public static double ejercicio11(double largoEscalera,double parteInferior) {

        double altura = Math.sqrt(largoEscalera*largoEscalera - parteInferior*parteInferior);
        System.out.println("punto 11: la escalera alcanzará " + altura + " metros");
        return altura;
    }
    // El punto 12 toma un numero entero de 3 cifras  y lo descompone en unidades, decenas y centenas.
    public static double ejercicio12(int numero) {
        int unidades = ( numero% 100)%10;
        int decenas =( numero% 100)/10;;
        int centenas =numero/100;
        System.out.println("punto 12 : " +numero + " es equivalente a  "+ unidades + " unidades , " + decenas + " decenas y " + centenas + " centenas");
        return numero;
    }
}


