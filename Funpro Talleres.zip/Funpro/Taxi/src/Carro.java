interface Carro {

    public void prender() throws Exception;
    public void apagar() throws Exception;
}

