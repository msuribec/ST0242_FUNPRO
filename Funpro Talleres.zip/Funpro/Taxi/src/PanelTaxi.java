import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

public class PanelTaxi extends JPanel implements ActionListener
{
    public final static String PRENDER = "prender";
    public final static String SUBIR = "subirPasajero";
    public final static String BAJAR = "bajarPasajero";
    public final static String APAGAR = "apagar";

    private JLabel labMensaje;
    private JButton butPrender;
    private JButton butSubir;
    private JButton butBajar;
    private JButton butApagar;
    private TaxiMauricio Taxi;
    private int numPasajeros;

    public PanelTaxi() {
        Taxi = new TaxiMauricio();

        setLayout( new GridLayout( 5, 1 ) );
        setPreferredSize( new Dimension( 0, 120 ) );
        TitledBorder border = BorderFactory.createTitledBorder( "App Taxi Mauricio" );
        border.setTitleColor( Color.BLUE );
        setBorder( border );

        butPrender = new JButton( "Prender" );
        butPrender.setActionCommand( PRENDER );
        butPrender.addActionListener( this );

        butSubir = new JButton( "Subir" );
        butSubir.setActionCommand( SUBIR );
        butSubir.addActionListener( this );

        butBajar = new JButton( "Bajar" );
        butBajar.setActionCommand( BAJAR );
        butBajar.addActionListener( this );

        butApagar = new JButton( "Apagar" );
        butApagar.setActionCommand( APAGAR );
        butApagar.addActionListener( this );

        labMensaje = new JLabel();

        add( butPrender );
        add( butSubir );
        add( butBajar );
        add( butApagar );
        add( labMensaje );
    }

    public void actionPerformed( ActionEvent evento )
    {
        String comando = evento.getActionCommand( );
        labMensaje.setText("");

        if( comando.equals( PRENDER ) )
        {
            try
            {
                Taxi.prender();
                labMensaje.setText("Taxi encendido");
                numPasajeros = 0;
            }
            catch(Exception excepcion)
            {
                String mensaje = excepcion.getMessage();
                labMensaje.setText(mensaje);
            }
        }
        else if( comando.equals( SUBIR ) )
        {
            try
            {
                Taxi.subirPasajero();
                labMensaje.setText("En servicio");
                numPasajeros++;
            }
            catch(Exception excepcion)
            {
                String mensaje = excepcion.getMessage();
                labMensaje.setText(mensaje);
            }
        }
        else if( comando.equals( BAJAR ) )
        {
            try
            {
                Taxi.bajarPasajero();
                labMensaje.setText("Disponible");
            }
            catch(Exception excepcion)
            {
                String mensaje = excepcion.getMessage();
                labMensaje.setText(mensaje);
            }
        }
        else if( comando.equals( APAGAR ) )
        {
            try
            {
                Taxi.apagar();
                labMensaje.setText("Taxi apagado, se transportaron " + numPasajeros + " pasajeros");
            }
            catch(Exception excepcion)
            {
                String mensaje = excepcion.getMessage();
                labMensaje.setText(mensaje);
            }
        }
    }
}
