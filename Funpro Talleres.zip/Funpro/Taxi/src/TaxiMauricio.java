class TaxiMauricio implements Carro, Transporte {

    boolean bolEncendido;
    boolean bolPasajero;

    public TaxiMauricio()
    {
        bolPasajero = false;
    }

    public void prender() throws Exception
    {
        if(bolEncendido == false)
        {
            bolEncendido = true;
        }
        else
        {
            throw new Exception ("El taxi ya está prendido");
        }
    }

    public void apagar() throws Exception
    {
        if(bolEncendido == true)
        {
            bolEncendido = false;
        }
        else
        {
            throw new Exception ("El taxi ya está apagado");
        }
    }

    public void subirPasajero() throws Exception
    {
        if(bolEncendido == true)
        {
            if(bolPasajero == false)
            {
                bolPasajero = true;
            }
            else
            {
                throw new Exception ("Ya hay un pasajero en el taxi");
            }
        }
        else
        {
            throw new Exception ("El taxi está apagado");
        }
    }

    public void bajarPasajero() throws Exception
    {
        if(bolEncendido == true)
        {
            if(bolPasajero == true)
            {
                bolPasajero = false;
            }
            else
            {
                throw new Exception ("No hay pasajeros montados en el taxi.");
            }
        }
        else
        {
            throw new Exception ("El taxi está apagado");
        }
    }
}