import java.awt.*;

import javax.swing.*;

public class InterfazTaxiMauricio extends JFrame
{
    private PanelTaxi panelTaxi;

    public InterfazTaxiMauricio() throws Exception
    {
        setTitle( "App Taxi Mauricio" );
        setSize( 290, 350 );
        setResizable( false );
        setDefaultCloseOperation( EXIT_ON_CLOSE );
        setLayout( new BorderLayout( ) );

        panelTaxi = new PanelTaxi();
        add( panelTaxi, BorderLayout.CENTER );
    }

    public static void main( String[] args )
    {
        try
        {
            InterfazTaxiMauricio interfazApp = new InterfazTaxiMauricio( );
            interfazApp.setVisible( true );
        }
        catch( Exception e )
        {
            e.printStackTrace( );
        }
    }
}
