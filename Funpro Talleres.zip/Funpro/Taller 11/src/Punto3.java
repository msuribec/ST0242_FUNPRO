
import java.util.Arrays;

public class Punto3 {

    public static void multiplicar(int[][] a ,int[][] b ){
        if (a[0].length == b.length){
            int[][] c = new int[a.length][b[0].length];
            for (int i =0;i< a.length;i++){
                for (int j =0;j< b[0].length;j++){
                    c[i][j] = 0;
                    for (int k =0;k< b.length;k++){
                        c[i][j]+= a[i][k] * b[k][j];
                    }
                }
            }
            for (int[] d: c) { System.out.println(Arrays.toString(d)); }
        }else{
            System.out.println("Es imposible multiplicar las matrices si el número de columnas de la matriz A no es igual al número de filas de la matriz B. ");
        }
    }

    public static void main(String []args){
        int[][] d = {{1,2,-2,0},{-3,4,7,2},{6,0,3,1}};
        int[][] e = {{-1,3},{0,9},{1,-11},{4,-5}};
        multiplicar(d,e);
    }
}
