
import java.util.Arrays;


public class Punto2 {

    public static String  nuevaMatriz(int size){
        int[][] m1 = new int[size][size];
        for (int i =0;i<m1[0].length;i++){
            m1[0][i] = 1;
            m1[m1.length-1][i] = 1;
            m1[i][0] = 1;
            m1[i][m1.length-1] = 1;
        }
        String result ="";
        for (int[]s: m1) {
            result+= Arrays.toString(s)+"\n";
        }
        return result;
    }

    public static void main(String []args){

        System.out.println(nuevaMatriz(4));
    }

}
