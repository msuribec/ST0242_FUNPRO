import java.util.ArrayList;
import java.util.Arrays;

public class Punto4 {
    public static void convertir (ArrayList<Integer> a){
        int size = (int) (Math.sqrt(a.size())) +1;
        int[][] b = new int[size][size];
        int count =0;
        for (int i =0;i<b.length;i++){
            for (int j =0;j<b.length;j++){
                if (count < a.size()){
                    b[i][j]= a.get(count);
                }else{
                    b[i][j]= 0;
                }
                count++;
            }
        }
        for (int[] d: b) { System.out.println(Arrays.toString(d)); }
    }



    public static void main(String []args){
        ArrayList<Integer> a = new ArrayList<Integer>();
        a.add(6);a.add(9);a.add(8);a.add(1);
        a.add(4);a.add(3);a.add(2);a.add(4);
        a.add(6);a.add(9);a.add(8);
        convertir(a);
    }
}
