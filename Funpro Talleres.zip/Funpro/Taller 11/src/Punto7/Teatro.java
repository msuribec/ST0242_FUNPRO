package Punto7;

import java.util.Arrays;

public class Teatro {

    private Persona[][] sala = new Persona[4][6];

    public void asignarAsiento(int fila, int col, Persona persona){
        if (sala[fila][col] == null) sala[fila][col] = persona;
        else System.out.println("El asiento está ocupado");
    }

    private Persona escogerElNombreMasFrecuente() {
        Persona campeon = sala[0][0];
        int contCampeon=0;
        for (Persona[] a: sala){
            for(int i=0;i<sala[0].length;i++){
                Persona retador = a[i];
                int contRetador=0;
                for (Persona[] b: sala){
                    for(int j=0;j<sala[0].length;j++){
                        if (a[i] != null && b[j]!= null){
                            if (a[i].getNombre().equalsIgnoreCase(b[j].getNombre())){
                                contRetador++;
                            }
                        }
                    }
                }

                if (contRetador>contCampeon){
                    contCampeon= contRetador;
                    campeon=retador;
                }
            }
        }
        return campeon;
    }

    private Persona escogerElMenor() {
        Persona menor = sala[0][0];
        int minEdad=menor.getEdad();
        for(Persona [] a: sala){
            for(int j=0;j<sala[0].length;j++){
                if (a[j] != null){
                    Persona retador = a[j];
                    int retadorEdad=retador.getEdad();
                    if(retadorEdad < minEdad){
                        minEdad = retadorEdad;
                        menor =retador;
                    }
                }
            }
        }
        return menor;
    }

    public void imprimir(){
        for (Persona[] a:sala) {
            System.out.println(Arrays.toString(a));
        }
    }



    public static void main(String []args){
        Teatro sala1 = new Teatro();
        Persona p1 =new Persona("María",54);
        Persona p2 =new Persona("María",54);
        Persona p3 =new Persona("daría",5);
        Persona p4 =new Persona("lina",5);

        sala1.asignarAsiento(3,4,p1);
        sala1.asignarAsiento(0,4,p2);
        sala1.asignarAsiento(1,2,p3);
        sala1.asignarAsiento(3,2,p1);
        sala1.asignarAsiento(2,2,p4);
        sala1.asignarAsiento(0,0,p4);
        sala1.asignarAsiento(1,0,p4);
        sala1.imprimir();
        System.out.println(sala1.escogerElNombreMasFrecuente());
        System.out.println(sala1.escogerElMenor());

    }
}
