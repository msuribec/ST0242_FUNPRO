import java.util.Arrays;

public class Punto5 {

    public static void invertir (int [][] a){
        int l = a[0].length;
        for (int i=0;i<l/2;i++){
            for (int j=0;j<a.length;j++){
                int k = l-1-i;
                int temp = a[j][i];
                a[j][i]= a[j][k];
                a[j][k] = temp;
            }
        }
        for (int[] b:a) {
            System.out.println(Arrays.toString(b));
        }
    }

    public static void main(String []args){
        int[][] d = {
                {3,5,7,9,10},
                {4,6,8,1,9},
                {1,4,5,7,14}};
        invertir(d);
    }
}
