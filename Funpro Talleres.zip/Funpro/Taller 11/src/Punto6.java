public class Punto6 {
    public static void pascal (int n){
        int mitad =(2*(n+1) -1)/2;
        int [][] a = new int[n+1][2*(n+1) -1];
        a[0][mitad]=1;
        int centroi =mitad - 1;
        int centrod=mitad +1;
        a[1][centroi]=1;
        a[1][centrod]=1;
        for (int i=2;i<a.length;i++){
            a[i][centroi-1] =1;
            a[i][centrod+1] =1;
            centroi--;
            centrod++;
        }
        for (int i=1;i<a.length -1;i++){
            for (int j=0;j<a[0].length-2;j++){
                if(a[i][j]!=0 ){
                    a[i+1][j+1]= a[i][j]+a[i][j+2];
                }
            }
        }
        for (int[] b:a) {
            for (int c:b) {
                if(c!=0) System.out.print(c);
                else System.out.print(" ");
            }System.out.println();
        }
    }

    public static void main(String []args){
        pascal(7);
    }
}
