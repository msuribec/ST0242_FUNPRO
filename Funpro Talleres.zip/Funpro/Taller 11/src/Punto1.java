import java.lang.reflect.Array;
import java.util.Arrays;

public class Punto1 {

    public static boolean comparar(int[][] enteros){
        int [][] enteros2= {{0,0,1}, {0,1,0}, {1,0,0}};
        return Arrays.deepEquals(enteros, enteros2);
    }

    public static void main(String []args){
        int [][] prueba = {{0,0,1},{0,1,0},{1,0,0}};
        System.out.println(comparar(prueba));
    }
}
