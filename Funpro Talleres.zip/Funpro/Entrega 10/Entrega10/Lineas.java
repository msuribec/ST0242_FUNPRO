/**
/* María Sofía Uribe 
 * Solución ejercicio en clase taller 9
 * 
 */

import java.awt.Point;
import java.util.*;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Line2D;


import javax.swing.JPanel;
import javax.swing.JFrame;
public class Lineas extends JPanel{
    static ArrayList<Punto> list = new ArrayList<Punto>();
    static Line2D.Double linea1 ;
    Color color ;
    
    @Override
    public void paintComponent(Graphics g) {
      Graphics2D g2d = (Graphics2D) g;
      for (int i = 0; i < list.size() -1; i++){
          g2d.setColor(color.CYAN);   
          linea1 = new Line2D.Double(list.get(i).getX(),list.get(i).getY(),list.get(i+1).getX(),list.get(i+1).getY());
          g2d.draw(linea1); 
      } 
      
      
    }
    
     public static void selectionSort(){
       Punto temporal;
       for (int i = 0; i < list.size()-1; i++) {
             for (int j = i+1; j < list.size(); j++) {
                if(list.get(i).getX()> list.get(j).getX()){
                    temporal = list.get(i);
                    list.set(i,list.get(j));
                    list.set(j,temporal);
                }else if (list.get(i).getX()== list.get(j).getX()){
                    if(list.get(i).getY()> list.get(j).getY()){
                        temporal = list.get(i);
                        list.set(i,list.get(j));
                        list.set(j,temporal);
                    }
                }   
            }
        }
        
        System.out.println(list);
    }
    
    public static void main(String[] args) {
        String str="";
        for (String a : args){ 
            str = str + a;
        }
        String[] intString = str.split(" "); 
	int [] integers = new int[intString.length];
	for (int i = 0; i < integers.length; i++){
	    integers[i] = Integer.parseInt(intString[i]);  
	}
	
	if (integers.length  % 2 == 0){
	    for (int i = 0; i < integers.length/2; i++){ 
	        list.add(new Punto(integers[i*2],integers[i*2+1]));
	       }
	   }else {
	       System.out.println("el numero de puntos debe ser par");
	   }
	selectionSort();
        JFrame frame = new JFrame("Dinujar lineas");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(new Lineas());
        frame.setSize(400, 400);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
	  
	}
}

