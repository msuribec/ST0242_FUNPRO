
/**
 * Solucion punto 6 del taller 6.
 * 
 * @author María Sofía Uribe 
 * @version MARZO 2018
 */
public class SolucionCuadPunto6
{
    public double a;
    public double b;
    public double c;

    public SolucionCuadPunto6(double a, double b, double c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }

    public void solucionar(){
        String result="";
        
        // ec incompleta
        if(c==0 && b==0){ //Solo el término de segundo grado
            result="x1 = 0"+"\n" + "x2= 0";
        }else if (c==0){
            result="x1= 0"+"\n" + "x2= "+ (-b/a); //Sin término independiente
        }else if (b==0){ //Sin término lineal
           if(-c/a>0){
               result="x1= "+ Math.sqrt(-c/a) +"\n" + "x2= "+ Math.sqrt(-c/a);
           }else if(-(c/a)<0){
               result ="raíces imaginarias";
           }
        // ec completa
        }else {
            double x1, x2, disc = Math.pow(b, 2) - (4 * a * c);
            if (disc > 0) {
                x1 = (-b + Math.sqrt(disc)) /(2*a);
                x2 = (-b - Math.sqrt(disc))/(2*a);
                System.out.println("disssc= " + (- b +Math.sqrt(disc)));
                result ="x1= "+ x1 + "\n"+"x2= "+x2;
            } else if (disc < 0) {
                result ="raíces complejas";
            } else { // discriminante es 0
                x1=-b/2*a;
                result="x1= "+x1;
            }
        }
        System.out.println("Las raíces son " + result);

    }

    public static void main(String []args) {
        //prueba punto 6
        SolucionCuadPunto6 uno = new SolucionCuadPunto6(10,4,15);
        uno.solucionar();
        //raíces complejas
        SolucionCuadPunto6 dos = new SolucionCuadPunto6(1,1,-4);
        dos.solucionar();
        //aprox x=1.56 , x= -2.56 
        SolucionCuadPunto6 tres = new SolucionCuadPunto6(1,-3,-4);
        tres.solucionar();
        //rpta x = –1, x=4
        SolucionCuadPunto6 cuatro = new SolucionCuadPunto6(1,-4,0);
        cuatro.solucionar();
        // x= 0 ,x=4
        SolucionCuadPunto6 cinco = new SolucionCuadPunto6(6,11,-35);
        cinco.solucionar();
        //rpta x = 1.66, x=-3.5
    }

}
