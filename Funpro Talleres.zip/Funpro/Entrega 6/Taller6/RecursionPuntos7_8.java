
/**
 * Solución puntoS 7 y 8 del taller 6.
 * 
 * @author María Sofía Uribe 
 * @version MARZO 2018
 */
public class RecursionPuntos7_8{
  //punto 7
    public static int mcd(int m, int n){
        int MCD=0;
        if(n>m){
            int temp=n;
            n=m;
            m=temp;
        }
        if(n==0){
            return m;
        }else {
            return mcd(n,m%n);
        }
    }
    //punto8

    public static int invertir(int n){
        int inv=0 , m=n , cuenta =0 , res = n%10;;
        if(n<=9) {
            inv +=n;
            return inv;
        }
        while(m>10){
            cuenta++;
            m = m/10;
        }
        inv += res* Math.pow(10.0,cuenta);
        cuenta--;
        inv+=invertir(n/10);
        return inv;
    }
    public static void main(String []args) {
        //punto 7
        System.out.println(mcd(100,20));
        //punto 8
        System.out.println(invertir(123456789));
    }

}
