
/**
 * Solucion punto 5 literales a y b del taller 6
 * @author (your name) 
 * @version (a version number or a date)
 */
public class PorValorYPorReferencia{  
    //punto 5 a) y b)
    public static void modificarEntero(int n) {
        n*=20;
    }

    public static void testModificarEntero() {
        int a =10;
        System.out.println("antes: " + a);
        modificarEntero(a);
        System.out.println("después: " + a);
    }

    public static void modificarDouble(double x) {
        x--;
    }

    public static void testDouble() {
        double d =10;
        System.out.println("antes: " + d);
        modificarDouble(d);
        System.out.println("después: " + d);
    }

    public static void main(String []args) {
        // Prueba 5a
        testModificarEntero();
        // Prueba 5b
        testDouble();


    }
}