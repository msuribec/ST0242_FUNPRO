
/**
 * Solción punto 5 literal c del taller 6
 * 
 * @author María Sofía Uirbe 
 * @version Marzo 2018
 */
public class Wrapper
{
    //punto 5 c)
    public int entero;

    public static void modificarObjeto(Wrapper objeto1){
        objeto1.entero =10;
    }

    public static void testModificarObjeto(){
        Wrapper obj1 = new Wrapper();
        System.out.println("antes: " + obj1.entero);
        modificarObjeto(obj1);
        System.out.println("después: " + obj1.entero);
    }

    public static void main(String []args) {
        //prueba 5c
        testModificarObjeto();
    }

}
