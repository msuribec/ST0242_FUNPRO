
/**
 * Soluciones de los putos 1 al 4 del taller 6
 * 
 * @author María Sofía Uribe
 * @version MARZO 2018
 */
public class Metodos{
    //punto1
    public static void printPowersOf3(int n) {
        for (int i=0;i<=n;i++){
            System.out.println((int)Math.pow(3, i));
        }
    }

    //punto2
    public static void printGrid(int numFilas, int numCols){
        for (int i= 1; i<=numFilas; i++){
            String resultado ="";
            for (int j= i; j<= numFilas*numCols-(numFilas-i); j=j+4){
                resultado += j +" ";
            }
            System.out.println(resultado);
        }
    }

    //punto3
    public static void invertirNombre(String s){
        String resultado="";
        for (int i= (s.length()-1); i>=1; i--){
            resultado+=s.charAt(i);
        }
        System.out.println(resultado);
    }

    //punto4
    public static void arbol(int segmentos,int altura){

        //segmentos del arbol
        int renglon=1, esp =0, star=0,seg;
        int max=(1+2*(segmentos-1)+2*(altura-1)); // número máximo de estrellas posibles
        for (seg= 1;seg <=segmentos; seg++){
            for( renglon= 1 ;renglon<=altura; renglon++) { //loop renglones
                for(esp=1; esp<= max -(renglon-1+altura)+1-seg; esp++) { // loop espacios
                    System.out.print(" ");
                }
                while(star != (1+2*(seg-1)+2*(renglon-1))) { // loop estrellas
                    System.out.print("*");
                    star++;
                }
                star = 0;
                System.out.println();
            }
        }

        // base del arbol
        int x=1;
        for(int rep=1; rep<=2; rep++){
            for(x=1; x<= max -altura; x++) { // loop espacios
                System.out.print(" ");
            }
            System.out.print("*"+"\n");
        }

        for(int a=1; a<=x-4; a++){
            System.out.print(" ");
        }
        System.out.println("*******");
    }


    public static void main(String []args) {
        // prueba punto 1
        //        printPowersOf3(10); 
        // prueba punto 2
        //        printGrid(4, 6);
        // prueba punto 3
                invertirNombre("juanita perez");
        // prueba punto 4
        //arbol(2,5);

}

}
