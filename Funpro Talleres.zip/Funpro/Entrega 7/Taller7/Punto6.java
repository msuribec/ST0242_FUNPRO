import javax.swing.JPanel;
import javax.swing.JFrame;
import java.awt.*;

public class Punto6 extends JPanel {
    @Override
    public void paintComponent(Graphics g) {
       figura5(g,100,40);
    }

    public void figura5(Graphics g,int x1,int y1){
        Graphics g2d = (Graphics) g;
        g2d.setColor(Color.BLUE);
        g2d.fillOval(x1,y1,40,40);// óvalo izquierdo
        g2d.setColor(Color.BLUE);
        g2d.fillOval(x1+80,y1,40,40);// óvalo derecho
        g2d.setColor(Color.RED);
        g2d.fillRect(x1+20,y1+20,80,80);// rectángulo
        g2d.setColor(Color.BLACK);
        g2d.drawLine(x1+20,(y1+60),x1+99,(y1+60));//linea
    }
    public static void main(String[] args) {
        JFrame jframe = new JFrame("Punto 6");
        jframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jframe.setBackground(Color.YELLOW);
        jframe.setPreferredSize(new Dimension(800, 800));
        jframe.add(new Punto6());
        jframe.pack();
        jframe.setLocationRelativeTo(null);
        jframe.setVisible(true);
    }

}
