import javax.swing.*;
import java.awt.*;

public class Punto8 extends JPanel {

    @Override
    public void paintComponent(Graphics g) {
        figura8(g,20,20,100);
        figura8(g,150,100,50);
    }

    public void figura8(Graphics g,int x,int y, int size){
        int espacio=size/5;
        Graphics g2d = (Graphics) g;
        g2d.setColor(Color.BLUE);
        g2d.drawLine(x,y,size+x,size+y);
        g2d.setColor(Color.RED);
        g2d.drawRect(x,y,size,size);// rectángulo
        for (int i=1;i<=5;i++){
            g2d.drawRect(x,y,i*espacio,i*espacio);
        }
    }
    
    public static void main(String[] args) {
        JFrame jframe = new JFrame("JFrame Size Example");
        jframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jframe.setBackground(Color.CYAN);
        jframe.setPreferredSize(new Dimension(300, 200));
        jframe.add(new Punto8());
        jframe.pack();
        jframe.setLocationRelativeTo(null);
        jframe.setVisible(true);




    }

}
