import javax.swing.JPanel;
import javax.swing.JFrame;
import java.awt.*;

/**
 * Ejemplo de Gráficas 2D
 * @author htrefftz
 */
public class Punto5 extends JPanel {

    @Override
    public void paintComponent(Graphics g) {
        Graphics g2d = (Graphics) g;

        g.setColor(Color.BLUE);
        g2d.fillOval(50,25,40,40);// óvalo izquierdo
        g.setColor(Color.BLUE);
        g2d.fillOval(130,25,40,40);// óvalo derecho
        g.setColor(Color.RED);
        g2d.fillRect(70,45,80,80);// rectángulo
        g.setColor(Color.BLACK);
        g2d.drawLine(70,85,149,85);//linea
    }

    public static void main(String[] args) {
        JFrame jframe = new JFrame("Punto 5");
        jframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jframe.setBackground(Color.YELLOW);
        jframe.setPreferredSize(new Dimension(220, 170));
        jframe.add(new Punto5());
        jframe.pack();
        jframe.setLocationRelativeTo(null);
        jframe.setVisible(true);




    }

}
