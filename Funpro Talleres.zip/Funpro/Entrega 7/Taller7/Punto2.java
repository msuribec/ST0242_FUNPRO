import java.awt.*;
import javax.swing.JPanel;
import javax.swing.JFrame;
import java.awt.geom.Ellipse2D;
import java.util.Random;
import java.awt.BasicStroke;
import java.awt.Graphics2D;
import java.awt.Graphics;

public class Punto2 extends JPanel {
    Ellipse2D.Double circulo;
    final static BasicStroke stroke = new BasicStroke(4.5f);

    @Override
    public void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g;
        for (int i=1; i<=10;i++){
            Random rand = new Random();
            int x = rand.nextInt((300 - 1) + 1) + 1;
            int y = rand.nextInt((300 - 1) + 1) + 1;
            int ancho = rand.nextInt((100 - 10) + 1) + 10;
            int alto = rand.nextInt((100 - 10) + 1) + 10;
            circulo = new Ellipse2D.Double(x,y,ancho,alto);
            g2.setStroke(stroke);
            g2.setColor(java.awt.Color.GRAY);
            g2.draw(circulo);
            g2.setColor(java.awt.Color.GREEN);
            g2.fill(circulo);
        }
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Punto 2");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(new Punto2());
        frame.setSize(400, 400);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

}
