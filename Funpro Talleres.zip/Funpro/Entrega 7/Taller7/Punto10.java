import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;
import java.util.Random;

public class Punto10 extends JPanel implements MouseListener {
    Rectangle2D.Double rec;
    Color color ;

    public Punto10() {
        rec = new Rectangle2D.Double(1,1,100,60);
        color =  new Color(24, 197, 164);
        this.addMouseListener(this);
    }

    @Override
    public void paintComponent(Graphics g) {
        circulos(g);
    }

    public void circulos(Graphics g) {
        Graphics2D g2 = (Graphics2D) g;
        g2.setColor(color);
        g2.draw(rec);
        g2.fill(rec);
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        Random rand = new Random();
        int red = rand.nextInt(255  + 1);
        int green = rand.nextInt(255  + 1);
        int blue = rand.nextInt(255  + 1);
        color =  new Color(red, green, blue);
        repaint();
    }

    @Override
    public void mouseEntered(MouseEvent e) {}

    @Override
    public void mouseExited(MouseEvent e) {}

    @Override
    public void mousePressed(MouseEvent e) {}
    @Override
    public void mouseReleased(MouseEvent e) {}

    public static void main(String[] args) {
        // Crear un nuevo Frame
        JFrame frame = new JFrame("Punto 10");
        // Al cerrar el frame, termina la ejecución de este programa
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        // Agregar un JPanel que se llama Points (esta clase)
        frame.add(new Punto10());
        // Asignarle tamaño: ancho y altura
        frame.setSize(400, 400);
        // Poner el frame en el centro de la pantalla
        frame.setLocationRelativeTo(null);
        // Mostrar el frame
        frame.setVisible(true);
    }
}
