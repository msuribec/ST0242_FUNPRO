import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Ellipse2D;
import javax.swing.JPanel;
import javax.swing.JFrame;

public class Punto3 extends JPanel implements MouseListener {
    Ellipse2D.Double circulo1, circulo2 ;
    int x1,y1,x2,y2;
    Boolean seleccionado= false, seleccionado2 = false;

    public Punto3() {
        circulo1 = new Ellipse2D.Double(1,1,40,40);
        circulo2 = new Ellipse2D.Double(60,20,40,40);
        this.addMouseListener(this);
    }

    @Override
    public void paintComponent(Graphics g) {
        circulos(g);
    }
    
    public void circulos(Graphics g) {
        Graphics2D g2 = (Graphics2D) g;
        g2.setColor(Color.RED);
        g2.fill(circulo1);
        g2.setColor(Color.BLUE);
        g2.fill(circulo2);
        if (seleccionado){
            g2.setColor(Color.RED);
            g2.fillOval(x1,y1,40,40);
            seleccionado =false;
        }
        if (seleccionado2){
            g2.setColor(Color.BLUE);
            g2.fillOval(x2,y2,40,40);
            seleccionado2 =false;
        }
    }

    @Override
    public void mouseClicked(MouseEvent e) {}

    @Override
    public void mouseEntered(MouseEvent e) {}

    @Override
    public void mouseExited(MouseEvent e) {}

    @Override
    public void mousePressed(MouseEvent e) {

        seleccionado=circulo1.getBounds().contains(e.getPoint());
        seleccionado2=circulo2.getBounds().contains(e.getPoint());

    }
    
    @Override
    public void mouseReleased(MouseEvent e) {
        if(seleccionado){
            x1=e.getX();
            y1 =e.getY();
            repaint();
        }
        if(seleccionado2){
            x2=e.getX();
            y2 =e.getY();
            repaint();
        }
    }
    public static void main(String[] args) {
        JFrame frame = new JFrame("Punto 3");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(new Punto3());
        frame.setSize(400, 400);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}
