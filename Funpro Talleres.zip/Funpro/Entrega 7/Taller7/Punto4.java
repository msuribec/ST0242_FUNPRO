import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

import java.awt.geom.Rectangle2D;
import javax.swing.JPanel;
import javax.swing.JFrame;

public class Punto4 extends JPanel implements MouseListener, MouseMotionListener{
    Rectangle2D rec1,rec2;
    Boolean seleccionado= false, seleccionado2= false;

    public Punto4() {
        rec1 = new Rectangle2D.Double(10,10,90,50);
        rec2 = new Rectangle2D.Double(1,100,90,50);
        this.addMouseListener(this);
        this.addMouseMotionListener(this);
    }

    @Override
    public void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g;
        super.paintComponent(g);
        g.setColor(Color.GRAY);
        g2.fill(rec1);
        g.setColor(Color.PINK);
        g2.fill(rec2);
    }

    @Override
    public void mouseClicked(MouseEvent e) { }

    @Override
    public void mousePressed(MouseEvent e) {
        seleccionado = rec1.contains(e.getPoint());
        seleccionado2= rec2.contains(e.getPoint());
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        seleccionado =false;
        seleccionado2 =false;
    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

    @Override
    public void mouseDragged(MouseEvent e) {
        if (seleccionado){
            rec1.setRect(e.getX(),e.getY(),100,40);
            repaint();
        }
        if (seleccionado2){
            rec2.setRect(e.getX(),e.getY(),100,40);
            repaint();
        }
    }

    @Override
    public void mouseMoved(MouseEvent e) {  }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Punto 4");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(new Punto4());
        frame.setSize(400, 400);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}
