import javax.swing.JPanel;
import java.awt.BasicStroke;
import javax.swing.JFrame;
import java.awt.geom.Rectangle2D;
import java.util.Random;
import java.awt.Graphics2D;
import java.awt.Graphics;

public class Punto1 extends JPanel {
    Rectangle2D.Double rect;
    final static BasicStroke stroke = new BasicStroke(3.0f);

    @Override
    public void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g;
        for (int i=1; i<=10;i++){
            Random rand = new Random();
            int x = 1+ rand.nextInt(250) ;
            int y = 1+ rand.nextInt(250);
            int ancho = 1 +rand.nextInt(150);
            int alto = 1 +rand.nextInt(150);
            rect = new Rectangle2D.Double(x,y,ancho,alto);
            g2.setStroke(stroke);
            g2.setColor(java.awt.Color.CYAN);
            g2.draw(rect);
            g2.setColor(java.awt.Color.BLUE);
            g2.fill(rect);
        }
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Punto 1");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(new Punto1());
        frame.setSize(400, 400);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

}
