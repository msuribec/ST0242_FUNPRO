import java.awt.Color;
import java.awt.Graphics;
//import java.awt.Graphics2D;
//import java.awt.geom.Line2D;
//import java.awt.*;
//import javax.swing.*;

import javax.swing.JPanel;
import javax.swing.JFrame;

/**
 * Ejemplo de Gráficas 2D
 * @author htrefftz
 */
public class Lineas2 extends JPanel {

    @Override
    public void paintComponent(Graphics g) {
       //puntos(g);
       //lineas(g);
       //rectangulo(g);
       //ovalos(g);
        //textos(g);
        //rectangulos(g);
        drawBook(g, 100, 200);
    }
    
    public void puntos(Graphics g) { g.drawLine(80, 80, 80, 80);}
    
    public void lineas(Graphics g) {g.drawLine(100, 100, 200, 300);}
    
    public void rectangulo(Graphics g) {
        // x, y, ancho, alto
        g.drawRect(10, 30, 100, 50);
        g.fillRect(160, 30, 100, 50);   
    }
    
    public void ovalos(Graphics g) {
        g.drawOval(10, 40, 40, 70);     
        g.fillOval(60, 40, 40, 70);        
    }
    
    public void textos(Graphics g) {
        for (int x = 1; x <= 4; x++) {
            for (int y = 1; y <= 9; y++) {
                g.drawString("Java", x * 40, y * 25);
            }
        }
    }
    
    public void rectangulos(Graphics g) {
        for (int i = 0; i < 5; i++) {
            g.drawRect(11 + 20 * i, 98 - 20 * i, 20, 20);
        }
    }
    
    // Draws a BJP textbook at the given x/y position.    
    public void drawBook(Graphics g, int x, int y) {
        g.setColor(Color.CYAN);            // cyan background
        g.fillRect(x, y, 100, 100);
        
        g.setColor(Color.WHITE);           // white "bjp" text
        g.drawString("BJP", x + 50, y + 20);
        
        g.setColor(new Color(191, 118, 73));
        for (int i = 0; i < 10; i++) {     // orange "bricks"
            g.fillRect(x, y + 10 * i, 10 * (i + 1), 9);
        }
    }

    
    public static void main(String[] args) {
        // Crear un nuevo Frame
        JFrame frame = new JFrame("Lineas");
        // Al cerrar el frame, termina la ejecución de este programa
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        // Agregar un JPanel que se llama Points (esta clase)
        frame.add(new Lineas2());
        // Asignarle tamaño
        frame.setSize(500, 400);
        // Poner el frame en el centro de la pantalla
        frame.setLocationRelativeTo(null);
        // Mostrar el frame
        frame.setVisible(true);
    }

}
