import javax.swing.*;
import java.awt.*;

public class Punto9 extends JPanel {

    @Override
    public void paintComponent(Graphics g) {
        sorpresa(g);
        aburrido(g);

    }

    public void sorpresa(Graphics g) {
        g.setColor(Color.YELLOW);
        g.fillOval(0, 0, 70, 70);
        g.setColor(Color.BLACK);
        g.fillOval(20, 20, 10, 10);
        g.fillOval(40, 20, 10, 10);
        g.setColor(Color.BLACK);
        g.drawOval(25, 40, 20, 20);
    }

    public void aburrido(Graphics g) {
        g.setColor(Color.YELLOW);
        g.fillOval(100, 0, 70, 70);
        g.setColor(Color.BLACK);
        g.fillOval(120, 20, 10, 10);
        g.fillOval(140, 20, 10, 10);

        g.drawLine(115, 45, 160, 45);
    }


    public static void main(String[] args) {
        // Crear un nuevo Frame
        JFrame frame = new JFrame("Punto 9");
        // Al cerrar el frame, termina la ejecución de este programa
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        // Agregar un JPanel que se llama Points (esta clase)
        frame.add(new Punto9());
        // Asignarle tamaño: ancho y altura
        frame.setSize(400, 400);
        // Poner el frame en el centro de la pantalla
        frame.setLocationRelativeTo(null);
        // Mostrar el frame
        frame.setVisible(true);
    }

}
