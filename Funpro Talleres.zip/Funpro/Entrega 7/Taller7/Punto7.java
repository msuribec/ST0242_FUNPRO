import javax.swing.*;
import java.awt.*;

/**
 * Ejemplo de Gráficas 2D
 * @author htrefftz
 */
public class Punto7 extends JPanel {



    @Override
    public void paintComponent(Graphics g) {
        Graphics g2d = (Graphics) g;
        g2d.setColor(Color.BLUE);
        g2d.drawLine(50,50,150,150);
        g2d.setColor(Color.RED);
        g2d.drawRect(50,50,100,100);// rectángulo
        g2d.drawRect(50,50,20,20);// rectángulo
        g2d.drawRect(50,50,40,40);// rectángulo
        g2d.drawRect(50,50,60,60);// rectángulo
        g2d.drawRect(50,50,80,80);// rectángulo

        g2d.drawRect(50,50,100,100);// rectángulo

    }

    public static void main(String[] args) {
        JFrame jframe = new JFrame("Punto 7");
        jframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jframe.setBackground(Color.CYAN);
        jframe.setPreferredSize(new Dimension(300, 200));
        jframe.add(new Punto7());
        jframe.pack();
        jframe.setLocationRelativeTo(null);
        jframe.setVisible(true);




    }

}
