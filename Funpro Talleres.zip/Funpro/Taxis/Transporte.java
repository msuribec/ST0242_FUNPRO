interface Transporte {

    public void subirPasajero() throws Exception;

    public void bajarPasajero() throws Exception;

}


