package Punto3;
import java.util.ArrayList;

public class ColeccionLibros {
    ArrayList<Libro> editorial = new ArrayList<Libro>();

    public void popularLibros(String titulo, String autor, int paginas){
        Libro l1= new Libro(titulo,autor,paginas);
        editorial.add(l1);
    }

    public String escritorMasProlijo() {
        String autorMasPag = editorial.get(0).getAutor();
        int maxPag =editorial.get(0).getPaginas();
        int n = editorial.size();
        for (int i = 0; i < n; i++) {
            int autorPag = editorial.get(i).getPaginas();
            for (int j = i+1; j < editorial.size(); j++) {
                if (editorial.get(i).getAutor().equalsIgnoreCase(editorial.get(j).getAutor())){
                    autorPag += editorial.get(j).getPaginas();
                }
            }
            if(autorPag > maxPag ){
                maxPag =autorPag;
                autorMasPag = editorial.get(i).getAutor();
            }
            if (i== n-1){
                n--;
            }
        }
        return autorMasPag;
    }



    public String escritorMasProlijo2() {
        String autorMasPag = editorial.get(0).getAutor();
        int maxPag =editorial.get(0).getPaginas();
        for (Libro l : editorial) {
            if(l.getPaginas() > maxPag ){
                maxPag =l.getPaginas();
                autorMasPag = l.getAutor();
            }
        }
        return autorMasPag;
    }

    public String librosPorAutor() {
        String autorCampeon = editorial.get(0).getAutor();
        int contAutorCampeon = 0;
        for (int i =0;i<editorial.size();i++){
            String autor = editorial.get(i).getAutor();
            int contAutor = 0;
            for (Libro j: editorial) {
                if (editorial.get(i).getAutor().equalsIgnoreCase(j.getAutor())){
                    contAutor++;
                }
            }
            if(contAutor>contAutorCampeon){
                contAutorCampeon= contAutor;
                autorCampeon = autor;
            }
        }
        return autorCampeon;
    }

    public String tituloMasLargo(){
        String autorTituloLargo = editorial.get(0).getAutor();
        String tituloLargo = editorial.get(0).getTitulo();
        int  sizeTituloLargo =editorial.get(0).getTitulo().length();
        for (Libro a : editorial){
            if(a.getTitulo().length() > sizeTituloLargo){
                autorTituloLargo = a.getAutor();
                tituloLargo = a.getTitulo();
                sizeTituloLargo =a.getTitulo().length();
            }
        }
        return "Título: "+tituloLargo +" , autor: " + autorTituloLargo;
    }


    public  void imprimir(){
        for (Libro a : editorial) { System.out.print(a); }
    }

    public static void main (String [] args ){
        ColeccionLibros c1 = new ColeccionLibros();
        c1.popularLibros("El Barco","Ruiz",50);
        c1.popularLibros("El Barco 2","Ruiz",10);
        c1.popularLibros("El Barco 3","Ruiz",10);
        c1.popularLibros("Peter Pan","Vargas",170);
        c1.popularLibros("Fahrenheit 451","Vargas",40);
        c1.popularLibros("Alicia en el País de las Maravillas","Palermo",200);
        c1.imprimir();
        System.out.println(c1.escritorMasProlijo());
        System.out.println(c1.escritorMasProlijo2());
        System.out.println(c1.tituloMasLargo());
        System.out.println(c1.librosPorAutor());
    }
}
