import java.util.ArrayList;

public class Puntos5y6 {

    ArrayList<Character> Caracteres = new ArrayList<Character>();
    public Puntos5y6 (ArrayList<Character> caracteres) { Caracteres = caracteres; }

    //con rep 3 letras
    public ArrayList<String> combinacionesRep (){
        ArrayList<String> comb = new ArrayList<String>();
        for (Character a: Caracteres) {
            for (Character b: Caracteres) {
                for (Character c: Caracteres){ comb.add(a.toString()+b.toString()+ c.toString());
                }
            }
        }return comb;
    }

    public ArrayList<String> combinacionesNoRep (ArrayList<String> rep){
        ArrayList<String> noRep = rep ;
        int n = noRep.size();
        int i =0;
        while(i<n){
            String str = noRep.get(i);
            for (int j = 0; j < str.length(); j++) {
                char c = str.charAt(j);
                if (cuantasVeces(str,c) > 1){
                    noRep.remove(i);
                    i--;
                    n--;
                    break;
                }
            }i++;
        }return noRep;
    }

    public int cuantasVeces(String str,char c) {
        int count =0;
        for (int i = 0; i < str.length(); i++) {
            if (str.charAt(i)== c){ count++; }
        }
        return count;
    }

    public ArrayList<String> combinaciones () {
        ArrayList<String> comb = new ArrayList<String>();
        for (Character a:Caracteres) {
            for (Character b:Caracteres) {
                comb.add(a.toString() + b.toString());
            }
         }return comb;
    }

    public static void main (String []args){
        ArrayList<Character> names = new ArrayList<Character>();
        names.add('a');names.add('b');names.add('c');
        Puntos5y6 c1 = new Puntos5y6(names);
        ArrayList<String> comb2 = c1.combinaciones();
        System.out.println(comb2);
        ArrayList<String> comb3 = c1.combinacionesRep();
        System.out.println(comb3);


        System.out.println(c1.combinacionesNoRep(comb3));
        System.out.println(c1.combinacionesNoRep(comb2));
    }
}
