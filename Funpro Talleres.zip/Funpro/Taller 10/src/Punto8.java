
import java.util.ArrayList;
import java.util.Scanner;

public class Punto8 {
    public static ArrayList<Integer> Coleccion = new ArrayList<>();

   private static Integer suma() {
       int suma=0;
       for (Integer s: Coleccion) { suma+= s; }
       return suma;
    }

    private static Double media() {
        return (double)suma()/(double)Coleccion.size();
    }

    private static Integer moda() {
        Integer campeon=Coleccion.get(0);
        int contCampeon=0;
        for (Integer retador: Coleccion) {
            int contRetador=0;
            for (Integer elemento: Coleccion) {
                if (retador.equals(elemento)){ contRetador++; }
            }
            if (contRetador>contCampeon){
                contCampeon= contRetador;
                campeon=retador;
            }
        }
        return campeon;
    }
    private static ArrayList<Integer> mayoresMedia() {
        ArrayList<Integer> mayores = new ArrayList<>();
        for (Integer s: Coleccion) {
            if (s > media()){ mayores.add(s); }
        }
        return mayores;
    }


    public static void main(String []args) {
        Scanner input = new Scanner(System.in);
        int n ;
        do{
            System.out.println("Ingrese un numero para ingresarlo al sistema, 99 para salir");
            n = input.nextInt();
            if (n== 99) { break; }
            Coleccion.add(n);
        }while(n > 0);

        System.out.println(Coleccion);
        System.out.println(moda());
        System.out.println(suma());
        System.out.println(media());
        System.out.println(mayoresMedia());
    }
}
