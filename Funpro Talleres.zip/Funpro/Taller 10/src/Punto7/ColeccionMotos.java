package Punto7;

import java.util.ArrayList;
import java.util.Scanner;

public class ColeccionMotos {
    static ArrayList<Moto> Coleccion = new ArrayList<Moto>();

    public static void listarTodas() {
        for (Moto a:Coleccion) { System.out.println(a); }
    }

    public static void listarMarca(String marca) {
        for (Moto a:Coleccion) {
            if (a.getMarca().equalsIgnoreCase(marca)){
                System.out.println(a);
            }
        }
    }

    public static void listarPorKilometros(int km) {
        for (Moto a:Coleccion ){
            if (a.getKm() > km) { System.out.println(a); }
        }
    }

    public static Moto listarMasTrajinada() {
        int maxKm = 0;
        Moto motoMaxKm = Coleccion.get(0);
        for (Moto a:Coleccion ){
            if (a.getKm() > maxKm) {
                maxKm = a.getKm();
                motoMaxKm = a;
            }
        }
        return motoMaxKm;
    }

     public  static ArrayList<Moto> ordenar(){
        Moto temporal;
        for (int i = 0; i < Coleccion.size()-1; i++) {
            for (int j = i+1; j < Coleccion.size(); j++) {
                if(Coleccion.get(i).getKm()> Coleccion.get(j).getKm()){
                    temporal = Coleccion.get(i);
                    Coleccion.set(i,Coleccion.get(j));
                    Coleccion.set(j,temporal);
                }
            }
        }
        return Coleccion;
    }

    public static void main(String []args) {
        Scanner input = new Scanner(System.in);
        int cent =1;
            do {
                System.out.println("Ingrese el kilometraje de la moto");
                int km = input.nextInt();
                System.out.println("Ingrese la placa de la moto");
                String placa = input.next();
                System.out.println("Ingrese la marca de la moto");
                String marca = input.next();
                System.out.println("Ingrese un numero positivo si desear añadir una moto ; negativo si no ");
                cent = input.nextInt();
                Coleccion.add(new Moto(placa, marca, km));
            }while(cent > 0);
        System.out.println(Coleccion);
        System.out.println(listarMasTrajinada());
        System.out.println(ordenar());
    }
}
