package Punto2;

public class Persona {
    private String nombre;
    private static String[] nombres = new String[]{"Mónica","Sofía","Marcela","Natalia","Daniela",
            "Verónica","Susana","Ana","Luisa","Manuela"};

    private Character genero;private int edad;private int peso;

    public Persona(String nombre, Character genero, int edad, int peso) {
        this.nombre = nombre;this.genero = genero;
        this.edad = edad;this.peso = peso;
    }

    public Persona() {
        setEdad();setGenero();
        setNombre();setPeso();
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre() {
        int r = (int) (Math.random() * (9 - 1)) + 1;
        this.nombre = nombres[r];
    }
    public Character getGenero() {
        return genero;
    }

    public void setGenero() {
        this.genero = (Math.random() <= 0.5) ? 'F': 'M';
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad() {
        this.edad = (int) (Math.random() * (90 - 1)) + 1;
    }

    public int getPeso() {
        return peso;
    }

    public void setPeso() { this.peso = (int) (Math.random() * (300 - 45)) + 45; }

    @Override public String toString() {
        return nombre + ", genero: " + genero + " , " + edad +" años , "+ peso + " kg." + "\n";
    }
}
