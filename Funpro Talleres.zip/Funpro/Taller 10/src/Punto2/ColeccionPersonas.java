package Punto2;
import java.util.ArrayList;
public class ColeccionPersonas {
    private ArrayList<Persona> personas = new ArrayList<Persona>();

    public void popularPersonas() {
        Persona p1 = new Persona();
        personas.add(p1);
    }
    public void ordenar(){
        Persona temporal;
        for (int i = 0; i < personas.size()-1; i++) {
            for (int j = i+1; j < personas.size(); j++) {
                if(personas.get(i).getEdad()> personas.get(j).getEdad()){
                    temporal = personas.get(i);
                    personas.set(i,personas.get(j));
                    personas.set(j,temporal);
                }else if (personas.get(i).getEdad()== personas.get(j).getEdad()){
                    if(personas.get(i).getPeso()> personas.get(j).getPeso()){
                        temporal = personas.get(i);
                        personas.set(i,personas.get(j));
                        personas.set(j,temporal);
                    }
                }
            }
        }
    }

    public void imprimir(){
        for (int i = 0; i < personas.size(); i++) {
            System.out.print(personas.get(i));
        }

    }

    public ArrayList<Persona> getPersonas() {
        return personas;
    }

    public void setPersonas(ArrayList<Persona> personas) {
        this.personas = personas;
    }

    public static void main(String[]args){
       ColeccionPersonas c1 = new ColeccionPersonas();
       c1.popularPersonas();
        c1.popularPersonas();
        c1.popularPersonas();
        c1.imprimir();
        System.out.println("Ordenado:");
        c1.ordenar();
        c1.imprimir();
    }


}
