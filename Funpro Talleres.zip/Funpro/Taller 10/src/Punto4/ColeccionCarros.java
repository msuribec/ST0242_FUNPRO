package Punto4;
import java.util.ArrayList;

public class ColeccionCarros {

    ArrayList<Carro> Coleccion = new ArrayList<Carro>();

    public ColeccionCarros(ArrayList<Carro> coleccion) {
        Coleccion = coleccion;
    }

    public ColeccionCarros() { }

    public void crear(Carro carro1){
        boolean exists=false;
        for (int i = 0; i < Coleccion.size(); i++) {
           if (Coleccion.get(i).getPlaca().equalsIgnoreCase(carro1.getPlaca())){
               exists = true;
               break;
           }
        }
        if (!exists){ Coleccion.add(carro1); }
    }

    public Carro leer(Carro carro1){
        boolean exists=false;
        int n = -1;
        for (int i = 0; i < Coleccion.size(); i++) {
            if (Coleccion.get(i).getPlaca().equalsIgnoreCase(carro1.getPlaca())){
                exists = true;
                n= i;
                break;
            }
        }
        if (exists){ return Coleccion.get(n); }
        return null;
    }


    public void actualizar (Carro carro1){
        boolean exists=false;
        int n = -1;
        for (int i = 0; i < Coleccion.size(); i++) {
            if (Coleccion.get(i).getPlaca().equalsIgnoreCase(carro1.getPlaca())){
                exists = true;
                n= i;
                break;
            }
        }
        if (exists){
           Coleccion.set(n,carro1);
        }
    }

    public void borrar (String placa1){
        boolean exists=false;
        int n = -1;
        for (int i = 0; i < Coleccion.size(); i++) {
            if (Coleccion.get(i).getPlaca().equalsIgnoreCase(placa1)){
                exists = true;
                n= i;
                break;
            }
        }
        if (exists){ Coleccion.remove(n); }
    }

    @Override public String toString() {
        return "ColeccionCarros{" + "Coleccion=" + Coleccion + '}';
    }

    public static void main (String []args){
        ColeccionCarros c1 = new ColeccionCarros();
        c1.crear(new Carro("ASE236","juan"));
        c1.crear(new Carro("EFD489","pedro"));
        c1.crear(new Carro("CEJ147","lisa"));
        c1.crear(new Carro("HTB473","cristina"));
        c1.crear(new Carro("MEA743","rosa"));
        Carro carro = new Carro("MEA743","margarita");
        c1.actualizar(carro);
        c1.borrar("ASE236");
        System.out.println(c1);
   }
}
