package Punto4;

public class Carro {
    String placa;
    String dueño;

    public Carro(String placa, String dueño) {
        this.placa = placa;
        this.dueño = dueño;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public String getDueño() {
        return dueño;
    }

    public void setDueño(String dueño) {
        this.dueño = dueño;
    }

    @Override
    public String toString() {
        return "Carro{" +
                "placa='" + placa + '\'' +
                ", dueño='" + dueño + '\'' +
                '}' + "\n";
    }
}
