
public class Multiplicar{
    float valor1, valor2 ,prod ;
    public Multiplicar(){
    }
    
}
