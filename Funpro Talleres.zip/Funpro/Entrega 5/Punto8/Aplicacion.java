public class Aplicacion {



    public static void main(String []args){
        Alumno alumno1 =new Alumno("Juliana", 13);
        alumno1.adicionar("Cálculo II", 3);
        alumno1.adicionar("Piano", 4);
        alumno1.adicionar("Biología", 4.1);
        alumno1.adicionar("Español", 5);
        
        alumno1.imprimir();

        Alumno alumno2 =new Alumno("Pablo", 15);
        alumno2.adicionar("Geometría", 3);
        alumno2.adicionar("Guitarra", 4);
        alumno2.adicionar("Química", 2);
        alumno2.adicionar("Español", 3);
        System.out.println(alumno2.promedio());
        alumno2.imprimir();
        
        

        Alumno alumno3 =new Alumno("Nicolás", 17);
        alumno3.adicionar("Física", 3);
        alumno3.adicionar("Inglés", 2.0);
        alumno3.adicionar("Cálculo I", 1.2);
        alumno3.adicionar("Francés", 5);
        alumno3.imprimir();

    }

}
