/*
 * María Sofía Uribe
 * FEB 2018
   */
public class Alumno {

    Asignatura Asig1 = new Asignatura();
    Asignatura Asig2 = new Asignatura();
    Asignatura Asig3 = new Asignatura();
    Asignatura Asig4 = new Asignatura();
    
    public static int numAsignaturas =0 ;
    private String nombre;
    private int edad;
    

    public Alumno(String nombre, int edad) {
        this.nombre = nombre;
        this.edad = edad;
    }

    public void adicionar(String nombreAsignatura, double nota){

        if (Asig1.getNombreAsignatura() != nombreAsignatura && Asig2.getNombreAsignatura() != nombreAsignatura && 
        Asig3.getNombreAsignatura() != nombreAsignatura && Asig4.getNombreAsignatura() != nombreAsignatura ){
            
            if (Asig1.getNombreAsignatura() == null){
                Asig1 = new Asignatura(nombreAsignatura, nota);
                numAsignaturas = 1;
            }else if(Asig2.getNombreAsignatura() == null){
                Asig2 = new Asignatura(nombreAsignatura, nota);
                numAsignaturas= 2;
            }else if(Asig3.getNombreAsignatura() == null){
                Asig3 = new Asignatura(nombreAsignatura, nota);
                numAsignaturas = 3;
            }else if(Asig4.getNombreAsignatura() == null){
                Asig4 = new Asignatura(nombreAsignatura, nota);
                numAsignaturas = 4;
            }else if (numAsignaturas >= 4){
                System.out.println("Este estudiante ya matriculó 4 materias");
            }
        }else {
            System.out.println ("Este estudiante ya inscribió " + nombreAsignatura);
        }
    }

    public String toString (){
        return "Estudiante: "+ nombre +"\nedad: "+ edad + "\ncursó: "+ Asig1.getNombreAsignatura()+ " " +
                Asig2.getNombreAsignatura()+" " + Asig3.getNombreAsignatura()+ " " + Asig4.getNombreAsignatura()+"\n" +
                Asig1.getNombreAsignatura()+ ": " + Asig1.getNota() + ", " + Asig1.calificacion() + "\n" +
                Asig2.getNombreAsignatura()+ ": " + Asig2.getNota() + ", " + Asig2.calificacion() + "\n" +
                Asig3.getNombreAsignatura()+ ": " + Asig3.getNota() + ", " + Asig3.calificacion() + "\n" +
                Asig4.getNombreAsignatura()+ ": " + Asig4.getNota() + ", " + Asig4.calificacion() + "\n" +
               promedio();
    }

    public double promedio(){
        return (Asig1.getNota() + Asig2.getNota() + Asig3.getNota() + Asig4.getNota()) / numAsignaturas;
    }

    public String getNombre() {
        return nombre;
    }

    private void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    private void setEdad(int edad) {
        this.edad = edad;
    }
}
