public class Estudiante {


    /**
     * Datos del estudiante.
     *
     */

        private String nombreEstudiante;
        private int idEstudiante;
        private int creditosAprobados = 0;
        private boolean yaPago ;

        public static final int CREDITOS_PARA_PRACTICA = 110;

        public Estudiante(String nombre, int id) {
            nombreEstudiante = nombre;
            idEstudiante = id;
        }

        public boolean puedeIrAPractica(){
            return  getYaPago() && getCreditosAprobados()>= CREDITOS_PARA_PRACTICA ;
        }

        public String toString(){
            return "Nombre del estudiante:" + getNombre() + "\nID:" + getId() +"\nCréditos aprobados:" +
                    getCreditosAprobados() + "\n¿ya pagó? "  + getYaPago() +  "\n¿puede ir a práctica? "  +puedeIrAPractica();
        }

       
        public String getNombre() {
            return nombreEstudiante;
        }

        public int getId() {
            return idEstudiante;
        }

        private void setCreditos(int creditos) {
            creditosAprobados = creditos;
        }

        public int getCreditosAprobados() {
            return creditosAprobados;
        }

        private void setYaPago(boolean pago) {
            yaPago = pago;
        }

        public boolean getYaPago() {
            return yaPago;
        }


        public static void main(String [] args) {
            //punto a
            
            Estudiante elMago = new Estudiante("Harry Potter", 123);
            elMago.setYaPago(true);
            elMago.setCreditos(120);
            System.out.println(elMago.toString());
           

       


        }
    }


