
/**
 * Ejemplo de problemas de privacidad
 *
 * @author Caperucita, poco antes de conocer el lobo
 * @version 2018-1
 */
public class Cliente
{
    public String nombre;
    public int saldo;

    public Cliente(String elNombre, int elSaldo) {
        nombre = elNombre;
        saldo = elSaldo;
    }

    private void setSaldo(int elSaldo) {
        saldo = elSaldo;
    }

    public int getSaldo() {
        return saldo;
    }

    public static void main(String [] args) {

    }
}
