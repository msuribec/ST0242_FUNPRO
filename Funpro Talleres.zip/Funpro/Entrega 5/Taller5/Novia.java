
/**
 * Write a description of class Novia here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Novia
{
    private String nombre;
    private String telefono;
    
    public Novia(String nombre, String telefono) {
        this.nombre = nombre;
        this.telefono = telefono;
    }
    
    public String toString() {
        return nombre + " " + telefono;
    }
    
    public static void main(String [] args) {
        Novia novia = new Novia ("Laura","3566478");
        System.out.println("Ella se llama: " + novia.nombre);
    }
}
