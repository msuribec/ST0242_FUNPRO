
/**
 * Clase para manejar números Racionales.
 * María Sofía Uribe
 * @author Basado en el libro The Art and Science of Java (Roberts 2008)
 * @version 2018-1
 */
public class Racional
{
    private int num;            // numerador
    private int den;            // denominador
    
    /**
     * Construye un nuevo número racional
     * @param x numerador del número racional
     * @param y denominador del número racional
     */
    public Racional(int x, int y) {
        int d = mcd(Math.abs(x), Math.abs(y));
        num = x / d;
        den = Math.abs(y) / d;
        if (y < 0)
            num = -num;
    }
    
    /**
     * Retorna la suma de dos números racionales
     * @param r1 primer número racional 
     * @param r2 regundo número racional
     * @return Nuevo número racional con la suma de r1 + r2
     */
    public static Racional sumar(Racional r1, Racional r2) {
        return new Racional(r1.num * r2.den + r2.num * r1.den,
            r1.den * r2.den);
    }
    
    /**
     * Retorna la representación, en String, del número racional
     * @return El String que representa el número racinoal
     */
    public String toString() {
        if(den == 1) {
            return "" + num;
        } else {
            return num + "/" + den;
        }
    }
    
    /**
     * Calcula el máximo común divisor usando el algoritmo de Euclides
     * @param x Primer entero
     * @param y Segundo entero
     * @return Máximo común divisor entre x e y
     */
    public int mcd(int x, int y) {
        int r = x % y;
        while(r != 0) {
            x = y;
            y = r;
            r = x % y;
        }
        return y;
    }
    // 3.a
    /**
     * Retorna la resta de dos números racionales
     * @param r1 primer número racional 
     * @param r2 regundo número racional
     * @return Nuevo número racional con la resta de r1 - r2
     */
    public static Racional resta(Racional r1, Racional r2) {
        return new Racional(r1.num * r2.den - r2.num * r1.den, r1.den * r2.den);
    }
     // 3.b
     /**
     * Retorna la multiplicación de dos números racionales
     * @param r1 primer número racional 
     * @param r2 regundo número racional
     * @return Nuevo número racional con la multiplicación de r1 * r2
     */
     public static Racional multiplicacion(Racional r1, Racional r2) {
        return new Racional(r1.num * r2.num , r1.den * r2.den);
    }
     // 3.c
    /**
     * Retorna la división de dos números racionales
     * @param r1 primer número racional 
     * @param r2 regundo número racional
     * @return Nuevo número racional con la división de r1 / r2
     */
     public static Racional division(Racional r1, Racional r2) {
        return new Racional(r1.num * r2.den , r1.den * r2.num);
    }

    public int getNum() {
        return num;
    }

    public double getDen() {
        return den;
    }

    /**
     * Programa principal para hacer pruebas
     */
    public static void main(String [] args) {
        
        Racional r1 = new Racional(1,3);
        Racional r2 = new Racional(1,2);
        //prueba 3.a
        Racional r3 = Racional.resta(r1, r2);
        System.out.println(r3);
        //prueba 3.b
        Racional r4 = Racional.multiplicacion(r1, r2);
        System.out.println(r4);
        //prueba 3.c
        Racional r5 = Racional.division(r1, r2);
        System.out.println(r5);
        
    }
}
