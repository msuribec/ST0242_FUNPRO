/* María Sofía Uribe
 * Feb 2018
   */

public class Asignatura {
    private String nombreAsignatura;
    private double nota ;
    
    public String calificacion(){
        return (nota >= 3.5) ? "Aprobado": "Reprobado";
    }

    public Asignatura(String nombreAsignatura, double nota) {
        this.nombreAsignatura = nombreAsignatura;
        this.nota = nota;
    }
    
    public Asignatura() {
        this (null,0);
    }

    public String getNombreAsignatura() {
        return nombreAsignatura;
    }

    private void setNombreAsignatura(String nombreAsignatura) {
        this.nombreAsignatura = nombreAsignatura;
    }

    public double getNota() {
        return nota;
    }

    private void setNota(double nota) {
        this.nota = nota;
    }
}
