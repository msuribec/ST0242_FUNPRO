/* María Sofía Uribe
 * FEB 2018
   */
public class Animal {
    public String nombre;
    public Boolean esqueletoOseo;
    public Boolean nacenDeHuevos;
    public Boolean respiranAire;
    public Boolean comenCarne;
    public Boolean comenPlantas;

    public Animal(String nombre, Boolean esqueletoOseo, Boolean nacenDeHuevos, Boolean respiranAire, Boolean comenCarne, Boolean comenPlantas) {

        this.nombre = nombre;
        this.esqueletoOseo = esqueletoOseo;
        this.nacenDeHuevos = nacenDeHuevos;
        this.respiranAire = respiranAire;
        this.comenCarne = comenCarne;
        this.comenPlantas = comenPlantas;

    }

    public String clasificar (){
        return "El animal es: " + ClasifEsqueleto() +" , "+ ClasifNacimiento() +" , "+ ClasifRespiracion() + " y " + ClasifAlimentacion();
    }

    public String ClasifEsqueleto() {
        return (esqueletoOseo) ? "Vertebrado ":"invertebrado";
    }

    public String ClasifNacimiento() {
        return (nacenDeHuevos) ? "Ovíparo":"Vivíparo";
    }

    public String ClasifRespiracion() {
        return (respiranAire) ? "Terrestre":"Acuático";
    }

    public String ClasifAlimentacion() {
        if (comenPlantas && comenCarne) return "Omnívoro";
        if (comenCarne) return "Carnívoro";
        return "Hervívoro";
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Boolean getEsqueletoOseo() {
        return esqueletoOseo;
    }

    public void setEsqueletoOseo(Boolean esqueletoOseo) {
        this.esqueletoOseo = esqueletoOseo;
    }

    public Boolean getNacenDeHuevos() {
        return nacenDeHuevos;
    }

    public void setNacenDeHuevos(Boolean nacenDeHuevos) {
        this.nacenDeHuevos = nacenDeHuevos;
    }

    public Boolean getRespiranAire() {
        return respiranAire;
    }

    public void setRespiranAire(Boolean respiranAire) {
        this.respiranAire = respiranAire;
    }

    public static void main(String [ ] args) {
        Animal perro = new Animal ("zazú",true,false,true,true,true);
        System.out.println(perro.clasificar());

    }

}

