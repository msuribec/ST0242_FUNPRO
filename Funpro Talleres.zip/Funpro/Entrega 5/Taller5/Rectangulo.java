
/**
 * Maneja la información de un rectángulo con lados paralelos
 * a los ejes X e Y.
 *  
 * @version 2018-1
 */
public class Rectangulo
{
    // coordenadas del punto inferior izquierdo
    private int x1;
    private int y1;
    // coordenadas del punto superior derecho
    private int x2;
    private int y2;

    public Rectangulo(int x1, int y1, int x2, int y2) {
        this.x1 = x1;
        this.y1 = y1;
        this.x2 = x2;
        this.y2 = y2;
    }
   
    public double area(){
       return (x2-x1)*(y2-y1); 
    }
   
    public double perimetro (){
        return 2* (x2-x1) + 2 *(y2-y1); 
    }

    public static void main(String [] args) {
          Rectangulo rect1 = new Rectangulo(1,5,6,7);
          System.out.println("area : " + rect1.area()); 
          System.out.println("perimetro : "+ rect1.perimetro()); 
        }
    




}
