
/**
 * Problemas de privacidad.
 *
 * @version 2018-1
 */
public class Banco
{
    private Cliente cliente;
    
    public Banco(Cliente elCliente) {

        cliente = elCliente;
    }
    
    public void modificarSalario(int elSaldo) {
        
        //ya que el método setSaldo es privado, la siguiente línea lanza un error 
        //cliente.setSaldo(elSaldo);
    }
}
