public class Aplicacion {



    public static void main(String []args){
        Alumno alumno1 =new Alumno("Juliana", 13);
        alumno1.adicionar("Cálculo II", 3);
        alumno1.adicionar("Piano", 4);
        alumno1.adicionar("Biología", 4.1);
        alumno1.adicionar("Español", 5);
        
        System.out.println(alumno1.toString());
        System.out.println();
        System.out.println();

        Alumno alumno2 =new Alumno("Pablo", 15);
        alumno2.adicionar("Geometría", 3);
        alumno2.adicionar("Guitarra", 4);
        // la clase Guitarra no se debe agregar 
        alumno2.adicionar("Guitarra", 2);
        alumno2.adicionar("Química", 2);
        alumno2.adicionar("Español", 3);
        
        System.out.println(alumno2.toString());
        System.out.println();
        System.out.println();

        Alumno alumno3 =new Alumno("Nicolás", 17);
        alumno3.adicionar("Física", 3);
        alumno3.adicionar("Inglés", 2.0);
        alumno3.adicionar("Cálculo I", 1.2);
        alumno3.adicionar("Francés", 5);
        System.out.println(alumno3.toString());

    }

}
