
/**
 * Ejemplo de un constructor con problemas.
 *
 * @version 2018-1
 */
public class Mascota
{
    private String nombre;

    public Mascota(String nombre) {
        this.nombre = nombre;
    }
    
    public static void main(String [] args) {
        Mascota miMascota = new Mascota("Trosky");
        System.out.println(miMascota.nombre);
    }
}
