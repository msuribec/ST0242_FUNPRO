import java.util.*;
public class HelloWorld{

     public static void main(String []args){
         ArrayList<String> list = new ArrayList<String>();
         list.add("medio");
         String str = "Hola";
         list.add(str);
         String s = list.get(1);
        System.out.println(s);
        list.set(1,"no");
         System.out.println(str);
     }
}