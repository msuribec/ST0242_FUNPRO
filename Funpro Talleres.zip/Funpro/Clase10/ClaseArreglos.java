import java.util.Arrays;
public class ClaseArreglos{
    
    public static int[] selectionSort(int[]nums){
       int n = nums.length;
       for(int i = 0;i<n -1;i++){
           int minIndex = i;
           for(int j = i+1;j<n;j++){
               if (nums[j]< nums[minIndex]){
                minIndex = j;
                }
            }
           if(minIndex !=i){
               swap(nums,minIndex,i);
        }
        }
       return nums;
    }
    
    public int laMasFrecuente(int [] nums){
        int campeona = nums[0];
        int contCampeona =0;
        for(int r =0;r<nums.length;r++){
            int retadora = nums[r];
            int contRetadora =0;
            for (int i =0;i <nums.length;i++){
            if(nums[i]== nums[r]){
                contRetadora++;
            }
            if(contRetadora > contCampeona){
            contCampeona = contRetadora;
            campeona = retadora;
            }
        
        }
        
        
        
    }
    
   return campeona;
    
}

 public static void swap(int [] nums, int pos1, int pos2){
    int t = nums[pos1];
    nums[pos1]= nums[pos2];
    nums[pos2] = t;
}
    }

