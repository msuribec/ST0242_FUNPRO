import java.util.*;
public class Ejercicio1{
    public static ArrayList<Integer> selectionSort(ArrayList<Integer> list){
    int temporal;

        for (int i = 0; i < list.size()-1; i++) {
            for (int j = i+1; j < list.size(); j++) {
                if(list.get(i)> list.get(j)){
                    temporal = list.get(i);
                    list.set(i,list.get(j));
                    list.set(j,temporal);
                }
            }
        }

        return list;
    }


public static void main(String []args){
    ArrayList<Integer> list = new ArrayList<Integer>();
    list.add(2); list.add(45);list.add(22);list.add(96);list.add(18); 
    list.add(95); list.add(102); list.add(13);list.add(3);list.add(11); 
    list.add(18);list.add(25);list.add(12);
    System.out.println(selectionSort(list));
    
}

}
