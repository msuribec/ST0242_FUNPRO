
public class Parcial{
 
    public static void dobleReversa(String str)
    {
        if (str.length() > 1){
            System.out.print("" + str.charAt(str.length()-1)+ str.charAt(str.length()-1));
            dobleReversa(str.substring(0,str.length()-1));
        }else if(str.length()==1){
            System.out.print(str+str);
        }
    }
    
    public static void main (String [] args){
        dobleReversa("hola");
    }
}
