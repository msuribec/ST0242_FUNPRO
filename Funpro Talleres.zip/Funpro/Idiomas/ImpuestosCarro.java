import javax.swing.JFrame;
import javax.swing.JPanel;
public class ImpuestosCarro extends JFrame {
        private JFrame panelDesc;
    private JFrame panelResult;
    public ImpuestosCarro() {
        panelDesc = new JFrame();
        panelResult = new JFrame("Título");
        panelDesc.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        panelDesc.setSize(400, 400);
        panelDesc.setLocationRelativeTo(null);
        panelDesc.setVisible(true);
    }
    
    public static void main(String[] args) {
        ImpuestosCarro i1= new ImpuestosCarro();
    }
}