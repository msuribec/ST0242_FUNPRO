public class Persona {
    private String nombre;
    private String apellido;
    public Persona(String apellido) {
        this.apellido = apellido;
    }
    
    public void imprimir() {
        System.out.println(nombre + " "+ apellido);
    }
}