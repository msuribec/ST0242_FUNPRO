package Punto3;

public class Persona {
    private String primerNombre,segundoNombre,primerApellido,segundoApellido,nombre,apellido;
    private int edad,talla ,peso;

    private int combinar;
    private Generador gen1 = new Generador();

    public Persona() {
        setEdad();
        setTalla();
        setPeso();
        int combinar = (Math.random() <= 0.5) ? 1 : 2;
      if (combinar == 1){
          nombre = gen1.getNombre();
          apellido = gen1.getApellido();
          gen1.setApellido();
          apellido+= " " + gen1.getApellido();
      }
      if (combinar ==2){
          primerNombre = gen1.getNombre();
          gen1.setNombre();
          segundoNombre = gen1.getNombre();
          while (primerNombre.equals(segundoNombre)){
              primerNombre = gen1.getNombre();
              gen1.setNombre();
              segundoNombre = gen1.getNombre();
          }
          primerApellido = gen1.getApellido();
          gen1.setApellido();
          segundoApellido = gen1.getApellido();
          while (primerApellido.equals(segundoApellido)){
              primerApellido = gen1.getApellido();
              gen1.setApellido();
              segundoApellido = gen1.getApellido();
          }
          nombre = primerNombre +" " +segundoNombre;
          apellido = primerApellido + " " +segundoApellido;


      }
    }

    public void setEdad() {

        this.edad = (int) (Math.random() * (90 - 1)) + 1;
    }

    public void setTalla() {
        this.talla = (int) (Math.random() * (40 - 4)) + 4;;
    }

    public void setPeso() {

        this.peso = (int) (Math.random() * (300 - 45)) + 45;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public int getEdad() {
        return edad;
    }

    public int getTalla() {
        return talla;
    }

    public int getPeso() {
        return peso;
    }

    @Override
    public String toString() {
        return  nombre + " " + apellido + " , "+ edad + " años, "+ "talla " + talla + " , " + peso+" kg" ;
    }
}
