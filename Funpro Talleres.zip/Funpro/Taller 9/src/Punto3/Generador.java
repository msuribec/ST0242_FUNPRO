package Punto3;
import java.util.Random;
public class Generador {

    private static String nombre,apellido;
    private static String[] nombres = new String[]{"Mónica","Sofía","Marcela","Natalia","Daniela",
            "Verónica","Susana","Ana","Luisa","Manuela"};
    private static String[] apellidos = new String[]{
            "Restrepo","Gómez","Trujillo","Giraldo","Calle",
            "Jaramillo","Uribe","Villa","Arturo","Yepes"};


    public Generador() {
        setApellido();
        setNombre();
    }

    public static String getNombre() {
        return nombre;
    }

    public void setNombre() {
        int r = (int) (Math.random() * (9 - 1)) + 1;
        this.nombre = nombres[r];
    }

    public static String getApellido() {
        return apellido;
    }

    public void setApellido() {
        int r = (int) (Math.random() * (9 - 1)) + 1;
        this.apellido = apellidos[r];
    }

    public static void main (String []args){

    }
}

