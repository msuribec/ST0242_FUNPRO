package Punto3;

import java.util.Scanner;
import java.util.*;

public class AppArrayList {
    public static void main (String []args){
        Scanner input = new Scanner(System.in);
        System.out.println("Ingrese número de personas");
        int num = input.nextInt();
        ArrayList <Persona> personas = new ArrayList<Persona>();
        for (int i =0;i<= num; i++){
            personas.add(new Persona());
            System.out.println(personas.get(i));
        }
    }

}


