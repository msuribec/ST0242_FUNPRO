package Punto3;
import java.util.Scanner;

public class App {

    public static void main (String []args){
        Scanner input = new Scanner(System.in);
        System.out.println("Ingrese número de personas");
        int num = input.nextInt();
       Persona[] personas = new Persona[num];

       for (int i =0;i< personas.length;i++){
           personas[i]= new Persona();
           System.out.println(personas[i]);
       }


    }

}


