package Punto5;

import java.util.Arrays;

public class Agenda {
    static Contacto[] contactos = new Contacto[100];
    String[] nombres ;

    public Agenda(Contacto[] contactos) {
        this.contactos = contactos;
    }

    public void crear(String nombre,int telefono){
        boolean exists=false,vacio=false;
        int n=-1;
        for (int i =0;i< contactos.length;i++){
            if(contactos[i] == null || contactos[i].getNombre().equals("")) { // Skips over null values. Add "|| "".equals(s)" if you want to exclude empty strings
                vacio = true;
                n = i;
            } else if (contactos[i].getNombre().equalsIgnoreCase(nombre)){
                exists = true;
                vacio = false;
            }
        }
        if (vacio && !exists) {
            contactos[n] = new Contacto(nombre, telefono);
        }
    }

    public void borrar(String nombre){
        Contacto[] refinedArray = new Contacto[contactos.length];
        int count = -1;
        for (int i =0;i< contactos.length;i++){
            if(contactos[i] == null || contactos[i].getNombre().equals("") || contactos[i].getNombre().equalsIgnoreCase(nombre)){ // Skips over null values. Add "|| "".equals(s)" if you want to exclude empty strings
                contactos[i]= null;
            }else {
                refinedArray[++count] = contactos[i];
            }
        }
        contactos= Arrays.copyOf(refinedArray, count + 1);
    }

    public void actualizar(String nombre,int telefono){
        for ( Contacto c :contactos) {
            if(c.getNombre().equalsIgnoreCase(nombre)){
                c.setTelefono(telefono);
                break;
            }
        }
    }

    public void leer(String nombre){
        for ( Contacto c :contactos) {
            if(c.getNombre().equalsIgnoreCase(nombre)){
                System.out.println(c);
                break;
            }
        }
    }

    @Override public String toString() {
        Contacto[] refinedArray = new Contacto[contactos.length]; // A temporary placeholder array
        int count = -1;
        for(Contacto s : contactos) {
            if(s != null ) { // Skips over null values. Add "|| "".equals(s)" if you want to exclude empty strings
                refinedArray[++count] = s; // Increments count and sets a value in the refined array
            }
        }
        contactos= Arrays.copyOf(refinedArray, count + 1);
        return " " + Arrays.toString(contactos).replace("[","").replace("]","").replace(",","");
    }

    public static void main (String []args){
        Contacto[] contactos = new Contacto[100];
        contactos[0]= new Contacto("Paula",500);
        contactos[1]= new Contacto("Harry",900);
        contactos[2]= new Contacto("Paul",1000);
        contactos[3]= new Contacto("Mia",805);
        Agenda ag1 = new Agenda(contactos);
        ag1.crear("Natalia",905);
        ag1.borrar("Mia");
        ag1.leer("Harry");

        ag1.actualizar("Paula",100);
        System.out.println(ag1.toString());
    }


}

