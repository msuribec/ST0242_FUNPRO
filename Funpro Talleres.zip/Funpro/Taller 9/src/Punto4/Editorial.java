package Punto4;
import java.util.Arrays;
public class Editorial {
    private  String[] autores;

    public void setAutores(String[] autores) {
        this.autores = autores;
    }

    public int contar(String str) {
        int cuenta =0;
        for (int i=0;i< autores.length;i++){
            if (str.equalsIgnoreCase(autores[i])) cuenta++;
        }
        return cuenta;
    }
    public String[] sinRep() {
        String[] arr = new String[autores.length];
        int n = autores.length;
        int index=0;
        for (int i = 0; i < n;i++) {
            boolean exists = false;
            for (int j = i+1; j < n; j++) {
                if (autores[i].equalsIgnoreCase(autores[j])) {
                    exists = true;
                    break;
                }
            }
            if (!exists) {
                arr[index] = autores[i];
            }else{
                index--;
            }
            index++;
        }
        String[] refinedArray = new String[arr.length]; // A temporary placeholder array
        int count = -1;
        for(String s : arr) {
            if(s != null) { // Skips over null values. Add "|| "".equals(s)" if you want to exclude empty strings
                refinedArray[++count] = s; // Increments count and sets a value in the refined array
            }
        }
        arr= Arrays.copyOf(refinedArray, count + 1);
        return arr;
    }

    public int vocab() {
        int cuenta =0;

        for (int i=0; i< autores.length;i++){
            String str = autores[i].toUpperCase();
            if (str.startsWith("A") || str.startsWith("E")
                    || str.startsWith("I") || str.startsWith("O")
                    || str.startsWith("U")
                    ){
                cuenta++;
            }
        }
        return cuenta;
    }


    public static void main (String []args){
        Editorial ed1 = new Editorial();
        String[] autores = new String[5];
        autores[0]="Arboleda";
        autores[1]="Orboleda";
        autores[2]="ulises";
        autores[3]="ulises";
        autores[4]="Arboleda";

        ed1.setAutores(autores);
        System.out.println(ed1.contar("garcia"));
        System.out.println(Arrays.toString(ed1.sinRep()));
        System.out.println(ed1.vocab());
    }

}
