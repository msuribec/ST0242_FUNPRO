import java.util.Scanner;
import java.util.Arrays;
/**
 * Write a description of class Triqui here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class TriquiMejorado {

    static boolean ganador;
    static String [][] tablero= new String [3][3];
    static int [][] matriz= new int [3][3];
    static int turno;

    public static void main (String []args){
        turno = 1;
        ganador =false;
        for (int fila =0;fila < matriz.length;fila++) Arrays.fill(matriz[fila], 7);
        while(!ganador && turno<=9){
            turnos();
            dibujar();
            elGanador();
            turno++;
        }
        System.out.println(resultado());
    }
    public static void turnos (){
        Scanner input = new Scanner(System.in);
        int x,y;
        if (turno%2 != 0){
            System.out.println("TURNO "+turno +" .Juega x ,escriba la coordenada en x");
            x = input.nextInt();
            System.out.println("Escriba la coordenada en y");
            y = input.nextInt();
            if (x > matriz.length -1 ||y > matriz.length -1 ){
                System.out.println("se ha entrado una coordenada que se sale de los campos");
                turno--;
            }else if(matriz[x][y] != 7 ){
                System.out.println("se ha entrado una que ya está ocupada");
                turno--;
            }
            else matriz[x][y] = 1;
        }
        if (turno%2 == 0){
            System.out.println("TURNO : "+turno + " .Juega O ,escriba la coordenada en x");
            x = input.nextInt();
            System.out.println("Escriba la coordenada en y");
            y = input.nextInt();
            if (x > matriz.length -1 ||y > matriz.length -1 ){
                System.out.println("se ha entrado una coordenada que se sale de los campos");
                turno--;
            }else if(matriz[x][y] != 7 ){
                System.out.println("se ha entrado una que ya está ocupada");
                turno--;
            }
            else matriz[x][y] = 0;

        }
    }

    public static void dibujar (){
        System.out.println("\f");
        System.out.println("\t---------");
        for (int fila =0;fila < matriz.length;fila++){
            for (int col =0;col <matriz[0].length;col++){
                if(matriz[fila][col] == 1) tablero[fila][col]="X";
                else if(matriz[fila][col] == 0) tablero[fila][col]="O";
                else tablero[fila][col]= " ";
            }
            String str1 =Arrays.toString(tablero[fila]);


            System.out.println("\t"+Arrays.toString(tablero[fila]).replace('[','|').replace(']','|')
                    .replace(',','|'));
            System.out.println("\t---------");
        }
    }

    public static void elGanador (){
        //diagonales
        if(matriz[0][0]+matriz[1][1]+matriz[2][2] == 3 || matriz[0][0]+matriz[1][1]+matriz[2][2] == 0){ ganador = true; }
        if(matriz[0][2]+matriz[1][1]+matriz[2][0] == 3 || matriz[0][2]+matriz[1][1]+matriz[2][0] == 0){ ganador = true; }
        //lineas y columnas
        for (int a = 0;a < matriz[0].length; a++) {
            int suma = 0;int suma2=0;
            for (int b = 0; b < matriz[0].length; b++) {
                suma = suma + matriz[a][b];
                suma2 = suma2 + matriz[b][a];
            }
            if (suma == 3 || suma == 0||suma2 == 3 || suma2 == 0) ganador = true;
        }
    }

    public static String resultado (){
        if(turno%2 !=0 && ganador) return "O GANÓ";
        else if (turno% 2 ==0 && ganador) return "X GANÓ";
        if(!ganador&& turno==9 ) return "EMPATE";
        return "";
    }
}

