import java.util.Scanner;
import java.util.Arrays;

public class Triqui
{
    static boolean ganador;
    static String [][] tablero= new String [3][3];
    static int [][] matriz= new int [3][3];
    static int turno;
    
    public static void main (String []args){
        turno = 1;
        ganador =false;
        for (int fila =0;fila < matriz.length;fila++){
            for (int col =0;col <matriz[0].length;col++){
                matriz[fila][col]= 7;
            }
        }

        while(!ganador && turno<=9){
            turnos();
            dibujar();
            elGanador();
            turno++;
        }
        System.out.println(resultado());
    }
    
    public static void turnos (){
        Scanner input = new Scanner(System.in);
        int x,y;
        if (turno%2 != 0){
            System.out.println("Es el turno de x ,escriba la coordenada en x");
            x = input.nextInt();
            System.out.println("Escriba la coordenada en y");
            y = input.nextInt();
            matriz[x][y] = 1;
        }

        if (turno%2 == 0){
            System.out.println("Es el turno de O ,escriba la coordenada en x");
            x = input.nextInt();
            System.out.println("Escriba la coordenada en y");
            y = input.nextInt();
            matriz[x][y] = 0;
        }
    }

    public static void dibujar (){
        for (int fila =0;fila < matriz.length;fila++){
            for (int col =0;col <matriz[0].length;col++){
                if(matriz[fila][col] == 1){
                    tablero[fila][col]="X";
                }else if(matriz[fila][col] == 0){
                    tablero[fila][col]="O";
                }else{
                    tablero[fila][col]=" ";
                }
            }
        }
        System.out.println(Arrays.toString(tablero[0]));
        System.out.println(Arrays.toString(tablero[1]));
        System.out.println(Arrays.toString(tablero[2]));
    }

    public static String resultado (){

        if(turno%2 !=0&& ganador){
            return "O GANÓ";
        }else if (turno% 2 ==0 &&ganador){
            return "X GANÓ";
        }

        if(!ganador&& turno==9 ){
            return "EMPATE";
        }
        return "EMPATE";
    }

    public static void elGanador (){
        //diagonales
        if(matriz[0][0]+matriz[1][1]+matriz[2][2] == 3 || matriz[0][0]+matriz[1][1]
        +matriz[2][2] == 0){ ganador = true; }
        if(matriz[0][2]+matriz[1][1]+matriz[2][0] == 3 || matriz[0][2]+matriz[1][1]
        +matriz[2][0] == 0){  ganador = true; }
        //lineas
        if(matriz[0][0]+matriz[0][1]+matriz[0][2] == 3 || 
        matriz[0][0]+matriz[0][1]+matriz[0][2] == 0){ ganador = true; }
        if(matriz[1][0]+matriz[1][1]+matriz[1][2] == 3 ||
        matriz[1][0]+matriz[1][1]+matriz[1][2] == 0){ ganador = true; }
        if(matriz[2][0]+matriz[2][1]+matriz[2][2] == 3 ||
        matriz[2][0]+matriz[2][1]+matriz[2][2] == 0){ ganador = true; }
        //columnas
        if(matriz[0][0]+matriz[1][0]+matriz[2][0] == 3 || matriz[0][0]+matriz[1][0]+matriz[2][0] == 0){ ganador = true; }
        if(matriz[0][1]+matriz[1][1]+matriz[2][1] == 3 || matriz[0][1]+matriz[1][1]+matriz[2][1] == 0){ ganador = true; }
        if(matriz[0][2]+matriz[1][2]+matriz[2][2] == 3 || matriz[0][2]+matriz[1][2]+matriz[2][2] == 0){ ganador = true; }
    }
}