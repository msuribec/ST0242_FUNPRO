import java.util.Scanner;

public class TriquiEjemplo
{
    // instance variables - replace the example below with your own
    private char [][] Juego = new char[3][3];
    private char Jugador;
    private boolean ganador;
    private int turnos;
    
    /**
     * Constructor for objects of class TriquiEjemplo
     */
    public TriquiEjemplo()
    {
        for(int i=0; i < 3; i++){
            for(int j=0; j < 3; j++)
                Juego[i][j] = ' ';
        }
        PintarMatriz();
        turnos = 0;
        ganador = false;
    }

    private void PintarMatriz()
    {
        System.out.print ('\f');
        System.out.println("\t-------------");
        for(int i=0; i < 3; i++){
            System.out.println("\t| " + Juego[i][0] + " | " + Juego[i][1] + " | " + Juego[i][2] + " |");
            System.out.println("\t-------------");
        }
    }
    
    private boolean getGanador()
    {
        return ganador;
    }
    
    private int getTurnos()
    {
        return turnos;
    }
    
    private void setJugador(char Jugador)
    {
        this.Jugador = Jugador;
    }
    
    private char getJugador()
    {
        return Jugador;
    }
    
    private boolean validarPosicion(int x, int y)
    {
        if(Juego[x][y] == ' ')
        {
            Juego[x][y] = Jugador;
            ganador = validarGanador();
            turnos++;
            PintarMatriz();
            return true;
        }
        return false;
    }
    
    private boolean validarGanador()
    {
        if(Juego[0][0] == Juego[0][1] && Juego[0][1] == Juego[0][2] && Juego[0][0] != ' ')
          return true;
        if(Juego[1][0] == Juego[1][1] && Juego[1][1] == Juego[1][2] && Juego[1][0] != ' ')
          return true;
        if(Juego[2][0] == Juego[2][1] && Juego[2][1] == Juego[2][2] && Juego[2][0] != ' ')
          return true;
        if(Juego[0][0] == Juego[1][0] && Juego[1][0] == Juego[2][0] && Juego[0][0] != ' ')
          return true;
        if(Juego[0][1] == Juego[1][1] && Juego[1][1] == Juego[2][1] && Juego[0][1] != ' ')
          return true;
        if(Juego[0][2] == Juego[1][2] && Juego[1][2] == Juego[2][2] && Juego[0][2] != ' ')
          return true;
        if(Juego[0][0] == Juego[1][1] && Juego[1][1] == Juego[2][2] && Juego[0][0] != ' ')
          return true;
        if(Juego[0][2] == Juego[1][1] && Juego[1][1] == Juego[2][0] && Juego[0][2] != ' ')
          return true;
        return false;
    }
    
    public static void main(String []args)
    {
	Scanner scannerEntrada = new Scanner(System.in);
	int x, y;
	boolean sePudoJugar = true;
        TriquiEjemplo nuevoJuego = new TriquiEjemplo();
        nuevoJuego.setJugador('O');
        while(!nuevoJuego.getGanador() && nuevoJuego.getTurnos() < 9)
        {
            if(nuevoJuego.getJugador() == 'O' && sePudoJugar)
                nuevoJuego.setJugador('X');
            else
            {
                if(nuevoJuego.getJugador() == 'X' && sePudoJugar)
                    nuevoJuego.setJugador('O');
            }
            System.out.println("Jugador " + nuevoJuego.getJugador() + " escriba su jugada");
            x = scannerEntrada.nextInt();
            y = scannerEntrada.nextInt();
            sePudoJugar = nuevoJuego.validarPosicion(x,y);
        }
        if(nuevoJuego.getGanador())
          System.out.println("Ganador: " + nuevoJuego.getJugador());
        else
          System.out.println("No hubo ganador");
        nuevoJuego = null;
    }
}
