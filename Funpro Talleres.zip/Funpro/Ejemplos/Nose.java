
/**
 * Write a description of class No here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

import java.awt.Color;
public class Nose
{
    
    public static void main(String[] args){
        
        Color color1 = Color.BLACK;
        System.out.println(color1);
        
        
    }
    
}
