
import java.io.*;
import java.util.*;

public class AppendText{
   
    public static void main(String[] args) {
      try(FileWriter fw = new FileWriter("words.txt", true);
      BufferedWriter bw = new BufferedWriter(fw);
      PrintWriter out = new PrintWriter(bw))
      {
          out.println("the text");
    //more code
    out.println("more text");
    //more code
} catch (IOException e) {
    System.err.println("IOException: " + e.getMessage());
}
    }
}
