 

import java.io.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Persistencia {
    public Persistencia (String jugador,int puntaje) {
        DateFormat archivo = new SimpleDateFormat("ddMMyyHHmm");
        DateFormat fecha = new SimpleDateFormat("dd/MM/yy");
        DateFormat hora = new SimpleDateFormat("HH:mm");
        Date dateobj = new Date();
        System.out.println(archivo.format(dateobj));
        BufferedWriter writer = null;
        try {
            //create a temporary file
            File logFile = new File(jugador+ archivo.format(dateobj));

            // This will output the full path where the file will be written to...
            //
            System.out.println(logFile.getCanonicalPath());
            writer = new BufferedWriter(new FileWriter(logFile));
            writer.write("Jugador: "+ jugador +System.getProperty("line.separator"));
            writer.write("Puntaje: "+ puntaje +System.getProperty("line.separator"));
            writer.write(fecha.format(dateobj)+System.getProperty("line.separator"));
            writer.write(hora.format(dateobj)+System.getProperty("line.separator"));
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                // Close the writer regardless of what happens...
                writer.close();
            } catch (Exception e) {
            }
        }
        
        
    }
    
    
    public static void main(String [] args){
        Persistencia p1 =new Persistencia("Sofia",3);
    
    }
    
}
