
/**
 * Soluciones al taller 1.
 * 
 * @author María Sofía Uribe
 * @version Enero 29 de 2018
 */
public class Taller1{
       public static void Estrellas2y3() {
        System.out.println("***** \n" +"***** \n");
        System.out.println("  *  \n" +"  *  \n" + "  *  ");
    }
    
    
    public static void Estrellas2y5() {
        System.out.println("***** \n" +"***** ");
        System.out.println(" * *  \n" +"  *  \n" + " * * ");
    }
    
    public static void punto6() {
        Estrellas2y5();
        System.out.println();
        Estrellas2y5();
        Estrellas2y3();
        Estrellas2y5();
    }

    public static void tres() {
        System.out.println("Llamar métodos es un concepto poderoso.");
        System.out.println("Llamar métodos es un concepto poderoso.");
        System.out.println("Llamar métodos es un concepto poderoso.");
    }

    public static void nueve() {
        tres();
        tres();
        tres();
        
    }

    public static void veinti7 () {
        nueve();
        nueve();
        nueve();
        
    }
    
      public static void ochenta1() {
        veinti7 ();
        veinti7 ();
        veinti7 ();
    }
    
     public static void punto7 () {
        ochenta1();
        ochenta1();
        ochenta1();
        
    }

    public static void main(String[] args) {
        punto6();
        punto7();
    }
}