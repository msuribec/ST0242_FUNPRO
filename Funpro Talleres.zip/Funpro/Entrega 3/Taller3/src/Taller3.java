public class Taller3 {

    public static void main (String []args){

    }

    public static void printTriangleType (int a, int b, int c){
        if ((a<b+c && b<a+c && c<a+b) && (a>=0 || b>= 0 || c>=0)){
            if (a==b  && a==c){
                System.out.println("equilátero");
            }else if(a==b || a==c || b==c){
                System.out.println("isósceles");
            }else{
                System.out.println("escaleno");
            }
        }else {
            System.out.println("Error, no se puede formar un triángulo con los valores");
        }
    }

    public static void punto6 (int x, int y){
        if (x%2 !=0){
            if(y%2 == 0){
                System.out.println("cierto");
            }else {
                System.out.println("Falso");
            }
        } else {
            System.out.println("Falso");
        }
    }

    public static void punto7 (int a, int b){
        if (a%2 !=0 ){
            if (b%2!=0){
                System.out.println("cierto");
            }
            else {
                System.out.println("falso");
            }
        }
        else{
            System.out.println("cierto");
        }
    }

    public static void punto8 (int fecha){
        // Calcular fecha
        int a =fecha/10000;
        int m= (fecha%10000)/100;
        int d= (fecha%10000)% 100;

        System.out.println(a + "/"+ m + "/" + d);

        //validación de la fecha
        boolean pruebames = (m ==4 || m==6 || m==9 || m==11) && d>30 ;
        boolean fechainvalida = fecha < 10000000 && fecha > 99999999;

        if ( fechainvalida || pruebames || d< 31 || m > 12 || (m ==2 & d > 28)) {
            System.out.println("No");
        }else{
            System.out.println("sí");
        }
    }

    public static void punto9(char color){
        if (color =='G' || color =='g'){
            System.out.println("Verde");
        }else if (color =='B' || color =='b'){
            System.out.println("Azul");
        }else if (color =='R' || color =='r'){
            System.out.println("Rojo");
        } else {
            System.out.println("Error, código inválido");
        }
    }

    public static void punto10(){
        System.out.println("1)true\n" + "2)true\n" + "3)esta expresion produce un error , la variable z no se ha declarado\n"
                + "4)true\n" + "5)false\n" + "6)esta expresion produce un error , la variable z no se ha declarado");
    }

        public static boolean hasPennies(int cents) {
            boolean nickelsOnly = (cents % 5 == 0);
            return nickelsOnly;
    }

    public static int numUnique (int uno, int dos, int tres){
        if (uno==dos  && uno==tres){
            return 3;
        }else if(uno==dos || uno==tres || dos==tres){
            return 2;
        }else {
            return 0;
        }
    }

    public static void punto13 (int valor){
        int billetes10 =valor/10000;
        int billetes5 =(valor%10000)/5000;
        int monedas =((valor%10000)%5000)/1000;

        boolean a =billetes10 ==0;
        boolean b =billetes5 ==0;
        boolean c =monedas ==0;
        String  bill10 =billetes10 + " billete(s) de 10000";
        String  bill5 =billetes5 + " billete(s) de 5000";
        String  moneda = monedas + " moneda(s) de 1000";

        if (a){
            if(b){
                if (c){
                    System.out.println("no aplica");
                }else {
                    System.out.println(moneda);
                }

            }else if (c){
                System.out.println(bill5);
            }else if (!c){
                System.out.println(bill5 +" y " + moneda);
            }

        }else if ( b){
            if(c){
                System.out.println(bill10);
            }else {
                System.out.println(bill10 +" y " + moneda);
            }
        }else {
            if (c){
                System.out.println(bill10 +" y " + bill5);
            }else {
                System.out.println(bill10 +" , " + bill5+" y " + moneda);
            }
        }
    }


    //método recibe el peso en kg, altura en metros y género de una persona y clasifica su imc
    //el char genero recibe f o F para mujeres y H o H para hombres
    public static void punto14 (double altura, double peso, char genero) {
        double imc = peso / (altura * altura) ;

        if (genero == 'h' || genero == 'H'){

            if (imc > 40) {
                System.out.println("Fuerte de obesidad");

            } else if (imc >= 31 && imc <= 40 ) {

                System.out.println("Obesidad");

            } else if (imc >= 26 && imc < 31) {

                System.out.println("Sobrepeso");

            } else if (imc >= 20 && imc < 26){

                System.out.println("Peso normal");

            } else { // por debajo de 20
                System.out.println("Falta de peso");
            }

        }else if (genero == 'F' || genero == 'f') {
            if (imc > 40) {
                System.out.println("Fuerte de obesidad");

            } else if (imc >= 31 && imc <= 40 ) {

                System.out.println("Obesidad");

            } else if (imc >= 25 && imc < 31) {

                System.out.println("Sobrepeso");

            } else if (imc >= 19 && imc < 25){

                System.out.println("Peso normal");

            } else { // por debajo de 19
                System.out.println("Falta de peso");
            }

        }else {

            System.out.print("Género no válido");
        }

    }

    public static void punto15 (int dia, int mes) {
        int calculo = 0;
        int i = 1;

        if (mes > 2 ) {
            if (mes ==4 || mes==5 ){
                i = 2;
            }else if (mes ==6 || mes==7 ){
                i = 3;
            }else if (mes >= 8 || mes<=9 ){
                i = 4;
            }else if (mes == 11|| mes==12 ){
                i = 5;
            }
                calculo = dia + 57 + (mes -3)*30 + i;

        }else if (mes ==1){
            calculo = dia-1;

        }else if (mes ==2 ){ calculo = mes + dia;
        }
        System.out.println("Faltan " + calculo + " días para tu cumpleaños");

    }

    public static void punto16 (int horas) {
        int salario;
        if (horas<= 40){
            salario =horas*10000;
        }else {
            salario = 400000 + 20000*(horas-40);
        }
        System.out.println("Salario: " + salario);
    }

    public static void punto17 (int litros) {
        int cobro;
        if (litros <= 50){
            cobro = 0;
        }else if (litros> 200) {
            cobro =60000 + 30000 * (litros - 50);
        }else {
            cobro =60000 + 50000 * (litros - 50);
        }
        System.out.println("cobro: " + cobro);
    }



}
