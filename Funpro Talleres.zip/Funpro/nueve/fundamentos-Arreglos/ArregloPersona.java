public class ArregloPersona
{
   //atributos
   private Persona[] listaP;
   
   //metodos
   public ArregloPersona(int n){
       listaP = new Persona[n];
       
       for(int i=0; i<n; i++){
          listaP[i] = new Persona(); 
       }
       
   }
}
