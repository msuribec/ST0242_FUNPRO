public class Arreglo
{
    //atributos
    private int[] listaInt;
    private double[] listaDouble;
    
    //metodos
    public Arreglo(int n){
        this.listaInt = new int[n];
        this.listaDouble = new double[n];
        for(int i=0; i<n; i++){
           this.listaInt[i]    = (int)(Math.random()*(2*n));
           this.listaDouble[i] = (Math.random()*(2*n));
        }
   
    }
    
    public void verListaDouble(){
        for(int i=0; i<this.listaInt.length; i++){
           System.out.println("["+i+"]: "+this.listaDouble[i]);
        }
    }
    
    public void verListaInt(){
       for(int i=0; i<this.listaInt.length; i++){
           System.out.println("["+i+"]: "+this.listaInt[i]);
        }
    }
    
    public int buscarMayorListaInt(){
        int mayor = this.listaInt[0];
        for(int i=1; i<this.listaInt.length; i++){
           if (mayor < this.listaInt[i]){
              mayor = this.listaInt[i]; 
           }
        }
        return mayor;
    }
    
    public double buscarMayorListaDouble(){
        double mayor = this.listaDouble[0];
        for(int i=1; i<this.listaDouble.length; i++){
           if (mayor < this.listaDouble[i]){
              mayor = this.listaDouble[i]; 
           }
        }
        return mayor;
    }
    
    
    public void ordenarAListaInt(){
        for(int i=0; i<listaInt.length-1; i++){
           for(int j=i+1; j<listaInt.length; j++){
              if (listaInt[i] > listaInt[j]){
                 int swap = listaInt[i];
                 listaInt[i] = listaInt[j];
                 listaInt[j] = swap;
              }
           }
        }
    }
    
    public void ordenarDListaInt(){
        for(int i=0; i<listaInt.length-1; i++){
           for(int j=i+1; j<listaInt.length; j++){
              if (listaInt[i] < listaInt[j]){
                 int swap = listaInt[i];
                 listaInt[i] = listaInt[j];
                 listaInt[j] = swap;
              }
           }
        }
    }
    
    public int[] cincoMayoresInt(){
       int[] resp = new int[5];
       ordenarDListaInt();
    
       for(int i=0; i<5; i++){
          resp[i] = listaInt[i]; 
       }
       return resp;
    }
}












