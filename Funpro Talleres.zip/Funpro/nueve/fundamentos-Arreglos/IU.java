/* Esta clase se relaciona con el usuario y el programa
*/
import java.util.Scanner;
public class IU
{
   //atributos
   static Scanner teclado = new Scanner(System.in);
    
   public static String leerTexto(String msg){
       //Scanner teclado = new Scanner(System.in);
       System.out.print(msg + ": ");
       String valor = teclado.nextLine();
       return valor;
    }
    
   public static int leerNumero(String msg){
       //Scanner teclado = new Scanner(System.in);
       System.out.print(msg + ": ");
       int valor = teclado.nextInt();
       teclado.nextLine();
       return valor;
    }
    
   public static double leerDecimal(String msg){
       //Scanner teclado = new Scanner(System.in);
       System.out.print(msg + ": ");
       double valor = teclado.nextDouble();
       teclado.nextLine();
       return valor;
    }
    
   public static void imprimir(String texto){
       System.out.println(texto); 
   }
    
}









