import java.util.Scanner;
public class Persona
{
    //atributos
    private String nombre;
    private double talla;
    
    //metodos
    public Persona (String nombre, double talla){
       this.nombre = nombre;
       this.talla = talla;
    }
    
    public Persona(){
       Scanner teclado = new Scanner(System.in);
       System.out.print("Nombre? ");
       this.nombre = teclado.nextLine();
       System.out.print("Talla? ");
       this.talla = teclado.nextDouble();
    }
    
    public String toString(){
       return "Persona {"+nombre+", talla: "+talla+"}\n";
    }
    
    public Persona masAlto(Persona p2){
       if (this.talla > p2.getTalla()){
          return this; 
       }return p2;
    }
    
    public double getTalla(){
       return this.talla;
    }
    
}



