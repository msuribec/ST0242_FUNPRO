
public class Programa
{
    //atributos
    private Datos persona1;
    private Datos persona2;
    
    //metodos
    public Programa()
    {
        this.persona1 = null;
        this.persona2 = null;
    }
    
    public void programa1(){
        //crear la persona 1
        String nombre = IU.leerTexto("Tu nombre?");
        int ano = IU.leerNumero("En que año naciste?");
        String id = IU.leerTexto("tu Id?");
        String dominio = IU.leerTexto("en cual dominio?");
        String ciudad = IU.leerTexto("Donde naciste?");
        double promedio = IU.leerDecimal("Y tu promedio es?");
        
        this.persona1 = new Datos(nombre, ano, id, 
                                  dominio, ciudad, promedio);
                                  
        
        this.persona2 = new Datos(
                   IU.leerTexto("Nombre?"),
                   IU.leerNumero("Año de nacimiento?"),
                   IU.leerTexto("Id?"),
                   IU.leerTexto("dominio"),
                   IU.leerTexto("Ciudad?"),
                   IU.leerDecimal("Promedio")
        );
        IU.imprimir("Persona 1");
        IU.imprimir(this.persona1.toString());
        IU.imprimir("Persona 2");
        IU.imprimir(this.persona2.toString());
    }

    public void compararCiudad(){
       if (this.persona1!= null && this.persona2!=null){
          IU.imprimir("Comparar ciudades");
          if (this.persona1.compararCiudad(this.persona2)){
              IU.imprimir(this.persona1.getNombre() + " y " +
                          this.persona2.getNombre() + " son de " +
                          this.persona1.getCiudad());
          } else {
              IU.imprimir(this.persona1.getNombre() + " es de " +
                          this.persona1.getCiudad() + " y " +
                          this.persona2.getNombre() + " es de " +
                          this.persona2.getCiudad() + 
                          " CIUDADES DIFERENTES :(");
          }
       } else {
           IU.imprimir(" No hay información....");
       }
    }
    
}







