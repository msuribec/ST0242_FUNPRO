
public class EjemploString
{
    //atributos
    private String texto1;
    private String texto2;
    
    //metodos
    
    public EjemploString()
    {
        this.texto1 = null;
        this.texto2 = "";
    }

}
