
public class Datos
{
    //atributos
    private String nombre;
    private int anoNacimiento;
    private String id;
    private String dominio;
    private String ciudad;
    private double promedio;
    
    //metodos
    public Datos(String nombre, int anoNacimiento, 
                 String id, String dominio, String ciudad, double promedio){
        this.nombre = nombre;
        this.anoNacimiento = anoNacimiento;
        this.id = id;
        this.dominio = dominio;
        this.ciudad = ciudad;
        this.promedio = promedio;       
    }
    
    public String toString(){
        return "Nombre: " + this.nombre + "\n"
             + "Año de nacimiento: " + this.anoNacimiento + "\n"
             + "email: " + this.id + "@" + this.dominio + "\n"
             + "Ciudad: " + this.ciudad + "\n"
             + "Promedio: " + this.promedio + "\n";
    }
    
    public String getNombre(){
       return this.nombre;
    }
    
    public String getCiudad() {
       return this.ciudad;
    }
    
    public boolean compararCiudad(Datos objX){
         return this.ciudad.equals(objX.getCiudad());
    }
}





