
/**
 * Write a description of class Tablero here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Tablero{
    int contadorMinas;
    int temporizador;
    Cuadricula[][] matriz = new Cuadricula[15][15];
    
    public void iniciarJuego(){
    }
    public void contarSegundos(){
    }
    public void contarMinas(){
    }
    public void imprimirTablero(){
    }
    public void TerminarJuego(){
    }
    
  
}
