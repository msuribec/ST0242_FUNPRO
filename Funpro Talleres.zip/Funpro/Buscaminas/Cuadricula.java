
public class Cuadricula {
    String estado;
    int numMinas;
    
    public void mostrarContenido(String estado){
    }
   
    

}

public class Tablero{
    int contadorMinas;
    int temporizador;
    Cuadricula[][] matriz = new Cuadricula[15][15];
    
    public void iniciarJuego(){
    }
    public void contarSegundos(){
    }
    public void contarMinas(){
    }
    public void imprimirTablero(){
    }
    public void TerminarJuego(){
    }
    
  
}


public class Jugador{
   
    public void descubrirCasillas(){
        
    }
}
