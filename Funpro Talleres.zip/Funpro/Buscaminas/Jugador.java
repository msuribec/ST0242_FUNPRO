
public class Jugador{
   
    public void descubrirCasillas(){
        
    }
}
