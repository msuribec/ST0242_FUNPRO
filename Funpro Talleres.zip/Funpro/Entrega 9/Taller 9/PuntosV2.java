/**
/* María Sofía Uribe 
 * Solución ejercicio en clase taller 9
 * 

 */

import java.awt.Point;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Line2D;
import java.awt.geom.Point2D;

import javax.swing.JPanel;
import javax.swing.JFrame;
public class PuntosV2 extends JPanel{

    static Puntos [] Punto ;
    static Line2D.Double linea1 ;
    Color color ;

    @Override
    public void paintComponent(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;
        for (int i = 0; i < Punto.length -1; i++){
            g2d.setColor(color.MAGENTA);
            linea1 = new Line2D.Double(Punto[i].getX(),
                Punto[i].getY(),Punto[i+1].getX(),Punto[i+1].getY());

            g2d.draw(linea1); 
        } 
    }

    public static void main(String[] args) {
        String str="";
        for (String a : args){ 
            str = str + a;
        }

        String[] intString = str.split(" "); 
        int [] integers = new int[intString.length];
        for (int i = 0; i < integers.length; i++){
            integers[i] = Integer.parseInt(intString[i]);

        }

        if (integers.length  % 2 == 0){
            Punto = new Puntos[integers.length/2];

            for (int i = 0; i < integers.length/2; i++){

                int x =integers[i*2];
                int y =integers[i*2+1];
                Punto [i] = new Puntos(x,y);

            }
        }else {
            System.out.println("el numero de puntos debe ser par");
        }

        JFrame frame = new JFrame("arregloPuntos");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(new PuntosV2());
        frame.setSize(400, 400);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

    }
}

