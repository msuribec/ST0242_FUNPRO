
/**
 * Write a description of class Puntos here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Puntos
{
    // instance variables - replace the example below with your own
    private int x;
     private int y;

    /**
     * Constructor for objects of class Puntos
     */
    public Puntos(int x, int y)
    {
        this.x= x;
        this.y =y;
    }

   
    public int getY()
    {
        // put your code here
        return y;
    }
    
    public int getX()
    {
        // put your code here
        return x;
    }
}
