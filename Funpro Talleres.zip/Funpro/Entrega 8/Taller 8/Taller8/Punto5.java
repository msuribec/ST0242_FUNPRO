import java.util.Scanner;

/**
 * Punto 5
 * @author Maria sofia uribe
 */
public class Punto5{
    public static void punto5(){
        Scanner input = new Scanner(System.in);
        System.out.println("Ingrese su ID:");
        String id = input.nextLine();
        System.out.println("Ingrese su dominio:");
        String dominio= input.nextLine();
        System.out.println("Este es su correo: ");
        System.out.println(id+"@"+dominio);
        System.out.println("validación de su cuenta. ");
        System.out.println("Ingrese su contraseña");
        String password1 = input.nextLine();
        System.out.println("Ingrese su contraseña de nuevo:");
        String password2 = input.nextLine();

        if ( password1.equals(password2) ) System.out.println("cuenta validada.");
        else System.out.println("las contraseñas no coinciden.Cuenta no establecida");


    }

    public static void main(String []args){
        punto5();
    }
    
}
