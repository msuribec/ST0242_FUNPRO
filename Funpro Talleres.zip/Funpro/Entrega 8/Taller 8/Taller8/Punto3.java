
/**
 * Punto 3 
 * @author Maria sofia uribe
 */
public class Punto3
{
   public static void invertirNombre(String s){
        String resultado="";
        for (int i= (s.length()-2); i>=0; i--){
            resultado+=s.charAt(i);
        }
        System.out.println(s+resultado);
    }
    
    public static void main(String []args){
        invertirNombre("goma");
     }
}
