import java.util.Scanner;

/**
 * Punto 4
 * @author Maria sofia uribe
 */
public class Punto4{
    public static void punto4(){
        String cen ="";
        int total=0;
        int ventas=0;
        do {
        Scanner input = new Scanner(System.in);
        System.out.println("Nombre del vendedor:");
        String nombre = input.nextLine();
        for (int i=1; i<=12;i++){
            System.out.println("Ingrese las ventas del mes " + i);
            int n = input.nextInt();
            ventas+=n;
        }
            System.out.println("Ventas de " + nombre +" : "+ ventas);
            total+=ventas;
            ventas=0;
            System.out.println("Escriba salir para parar o continuar para ingresar otro vendedor" );
            cen = input.next();
        }while(cen.equalsIgnoreCase("continuar"));
        System.out.println("Total ventas = " + total);
    }

    public static void main(String []args){
        punto4();
    }

}
